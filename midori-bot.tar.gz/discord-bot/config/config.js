require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID,
  prefix: process.env.PREFIX || '+',
  port: parseInt(process.env.PORT) || 3001,
  ownerId: process.env.OWNER_ID || '',
  colors: {
    main: '#2b2d31',
    success: '#57F287',
    error: '#ED4245',
    warn: '#FEE75C',
    info: '#5865F2',
  },
  emojis: {
    success: '✅',
    error: '❌',
    warn: '⚠️',
    loading: '⏳',
    midori: '緑',
  },
};
