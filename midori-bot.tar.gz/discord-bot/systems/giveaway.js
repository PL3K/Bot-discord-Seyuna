const { EmbedBuilder } = require('discord.js');
const { giveaways } = require('./database');

async function endGiveaway(client, ga) {
  if (!ga || ga.ended) return;

  try {
    const channel = await client.channels.fetch(ga.channel_id).catch(() => null);
    if (!channel) { giveaways.end.run('[]', ga.id); return; }

    const message = await channel.messages.fetch(ga.message_id).catch(() => null);
    let winners = [];

    if (message) {
      const reaction = message.reactions.cache.get('🎉');
      if (reaction) {
        const users = await reaction.users.fetch().catch(() => null);
        if (users) {
          const eligible = [...users.filter(u => !u.bot).values()];
          const count = Math.min(ga.winners_count, eligible.length);
          const shuffled = eligible.sort(() => Math.random() - 0.5);
          winners = shuffled.slice(0, count);
        }
      }
    }

    giveaways.end.run(JSON.stringify(winners.map(w => w.id)), ga.id);

    const endEmbed = new EmbedBuilder()
      .setColor(winners.length ? '#F1C40F' : '#ED4245')
      .setTitle(`🎊 GIVEAWAY TERMINÉ — ${ga.prize}`)
      .setDescription(
        winners.length
          ? `🏆 **Gagnant(s):** ${winners.map(w => w.toString()).join(', ')}\n🎁 **Prix:** ${ga.prize}\n👤 **Organisateur:** <@${ga.host_id}>`
          : `❌ Pas de gagnants (personne n'a participé).\n🎁 **Prix:** ${ga.prize}`
      )
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();

    if (message) {
      await message.edit({ embeds: [endEmbed] }).catch(() => {});
      if (winners.length) {
        await channel.send({ content: `🎉 Félicitations ${winners.map(w => w.toString()).join(', ')}! Vous gagnez **${ga.prize}**!`, embeds: [endEmbed] });
      } else {
        await channel.send({ embeds: [endEmbed] });
      }
    }
  } catch (e) {
    console.error('[Giveaway]', e.message);
    giveaways.end.run('[]', ga.id);
  }
}

module.exports = { endGiveaway };
