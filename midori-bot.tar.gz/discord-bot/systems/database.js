const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, 'midori.db'));
db.exec('PRAGMA journal_mode = WAL;');

db.exec(`
  CREATE TABLE IF NOT EXISTS guild_config (
    guild_id TEXT PRIMARY KEY,
    prefix TEXT DEFAULT '+',
    mod_log TEXT, message_log TEXT, ticket_log TEXT,
    giveaway_log TEXT, boost_log TEXT, raid_log TEXT,
    welcome_channel TEXT, leave_channel TEXT,
    auto_role TEXT, mute_role TEXT,
    ticket_category TEXT, suggest_channel TEXT,
    antiraid_enabled INTEGER DEFAULT 0,
    antispam_enabled INTEGER DEFAULT 1,
    antilink TEXT DEFAULT 'off',
    antieveryone INTEGER DEFAULT 0,
    antiadmin INTEGER DEFAULT 0,
    antiban INTEGER DEFAULT 0,
    antibot INTEGER DEFAULT 0,
    antichannel_create INTEGER DEFAULT 0,
    antichannel_delete INTEGER DEFAULT 0,
    antichannel_update INTEGER DEFAULT 0,
    antirole_create INTEGER DEFAULT 0,
    antirole_delete INTEGER DEFAULT 0,
    antirole_update INTEGER DEFAULT 0,
    antiwebhook INTEGER DEFAULT 0,
    antidown INTEGER DEFAULT 0,
    antiupdate INTEGER DEFAULT 0,
    ghostping_channel TEXT,
    punition TEXT DEFAULT 'kick',
    server_locked INTEGER DEFAULT 0,
    updated_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS xp (
    user_id TEXT NOT NULL, guild_id TEXT NOT NULL,
    xp INTEGER DEFAULT 0, level INTEGER DEFAULT 0,
    messages INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, guild_id)
  );

  CREATE TABLE IF NOT EXISTS warns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT, guild_id TEXT, moderator_id TEXT,
    reason TEXT, created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT, user_id TEXT, guild_id TEXT,
    status TEXT DEFAULT 'open',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS giveaways (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT, channel_id TEXT, guild_id TEXT,
    host_id TEXT, prize TEXT, winners_count INTEGER DEFAULT 1,
    ends_at INTEGER, ended INTEGER DEFAULT 0, winners TEXT
  );

  CREATE TABLE IF NOT EXISTS marriages (
    user1_id TEXT, user2_id TEXT,
    guild_id TEXT, married_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (user1_id, guild_id)
  );

  CREATE TABLE IF NOT EXISTS snipe (
    guild_id TEXT, channel_id TEXT,
    author_id TEXT, content TEXT, deleted_at TEXT,
    PRIMARY KEY (channel_id)
  );

  CREATE TABLE IF NOT EXISTS suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT, user_id TEXT, guild_id TEXT,
    content TEXT, status TEXT DEFAULT 'pending',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS button_roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT, guild_id TEXT,
    role_id TEXT, description TEXT
  );

  CREATE TABLE IF NOT EXISTS whitelist (
    user_id TEXT, guild_id TEXT,
    added_by TEXT, PRIMARY KEY (user_id, guild_id)
  );

  CREATE TABLE IF NOT EXISTS temp_vocs (
    channel_id TEXT PRIMARY KEY,
    owner_id TEXT, guild_id TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// ── helpers ──────────────────────────────────────────────
const getConfig = db.prepare('SELECT * FROM guild_config WHERE guild_id = ?');
const upsertConfig = (guildId, fields) => {
  const existing = getConfig.get(guildId) || {};
  const merged = { ...existing, ...fields, guild_id: guildId };
  const cols = Object.keys(merged).join(', ');
  const vals = Object.keys(merged).map(() => '?').join(', ');
  const updates = Object.keys(merged).filter(k => k !== 'guild_id').map(k => `${k} = excluded.${k}`).join(', ');
  db.prepare(`INSERT INTO guild_config (${cols}) VALUES (${vals}) ON CONFLICT(guild_id) DO UPDATE SET ${updates}`).run(...Object.values(merged));
  return getConfig.get(guildId);
};

module.exports = {
  db,
  getConfig: (guildId) => getConfig.get(guildId) || { prefix: '+' },
  upsertConfig,
  warns: {
    add: db.prepare('INSERT INTO warns (user_id, guild_id, moderator_id, reason) VALUES (?, ?, ?, ?)'),
    get: db.prepare('SELECT * FROM warns WHERE user_id = ? AND guild_id = ? ORDER BY id DESC'),
    count: db.prepare('SELECT COUNT(*) as n FROM warns WHERE user_id = ? AND guild_id = ?'),
    remove: db.prepare('DELETE FROM warns WHERE id = ? AND guild_id = ?'),
    clear: db.prepare('DELETE FROM warns WHERE user_id = ? AND guild_id = ?'),
  },
  tickets: {
    create: db.prepare('INSERT INTO tickets (channel_id, user_id, guild_id) VALUES (?, ?, ?)'),
    getByChannel: db.prepare('SELECT * FROM tickets WHERE channel_id = ? AND status = ?'),
    getByUser: db.prepare('SELECT * FROM tickets WHERE user_id = ? AND guild_id = ? AND status = ?'),
    close: db.prepare('UPDATE tickets SET status = ? WHERE channel_id = ?'),
  },
  giveaways: {
    create: db.prepare('INSERT INTO giveaways (channel_id, guild_id, host_id, prize, winners_count, ends_at) VALUES (?, ?, ?, ?, ?, ?)'),
    setMsg: db.prepare('UPDATE giveaways SET message_id = ? WHERE id = ?'),
    getByMsg: db.prepare('SELECT * FROM giveaways WHERE message_id = ?'),
    getById: db.prepare('SELECT * FROM giveaways WHERE id = ?'),
    getActive: db.prepare('SELECT * FROM giveaways WHERE guild_id = ? AND ended = 0'),
    end: db.prepare('UPDATE giveaways SET ended = 1, winners = ? WHERE id = ?'),
  },
  marriages: {
    get: db.prepare('SELECT * FROM marriages WHERE (user1_id = ? OR user2_id = ?) AND guild_id = ?'),
    add: db.prepare('INSERT OR REPLACE INTO marriages (user1_id, user2_id, guild_id) VALUES (?, ?, ?)'),
    remove: db.prepare('DELETE FROM marriages WHERE (user1_id = ? OR user2_id = ?) AND guild_id = ?'),
  },
  snipe: {
    set: db.prepare('INSERT OR REPLACE INTO snipe (guild_id, channel_id, author_id, content, deleted_at) VALUES (?, ?, ?, ?, datetime(\'now\'))'),
    get: db.prepare('SELECT * FROM snipe WHERE channel_id = ?'),
  },
  whitelist: {
    add: db.prepare('INSERT OR IGNORE INTO whitelist (user_id, guild_id, added_by) VALUES (?, ?, ?)'),
    remove: db.prepare('DELETE FROM whitelist WHERE user_id = ? AND guild_id = ?'),
    check: db.prepare('SELECT * FROM whitelist WHERE user_id = ? AND guild_id = ?'),
    getAll: db.prepare('SELECT * FROM whitelist WHERE guild_id = ?'),
  },
  tempVocs: {
    add: db.prepare('INSERT OR REPLACE INTO temp_vocs (channel_id, owner_id, guild_id) VALUES (?, ?, ?)'),
    get: db.prepare('SELECT * FROM temp_vocs WHERE channel_id = ?'),
    getByOwner: db.prepare('SELECT * FROM temp_vocs WHERE owner_id = ? AND guild_id = ?'),
    delete: db.prepare('DELETE FROM temp_vocs WHERE channel_id = ?'),
  },
  xp: {
    get: db.prepare('SELECT * FROM xp WHERE user_id = ? AND guild_id = ?'),
    upsert: db.prepare('INSERT INTO xp (user_id, guild_id, xp, level, messages) VALUES (?, ?, ?, 0, 1) ON CONFLICT(user_id, guild_id) DO UPDATE SET xp = excluded.xp, level = excluded.level, messages = messages + 1'),
    top: db.prepare('SELECT * FROM xp WHERE guild_id = ? ORDER BY xp DESC LIMIT 10'),
  },
};
