const { readdirSync } = require('fs');
const path = require('path');

module.exports = (client) => {
  const eventsDir = path.join(__dirname, '..', 'events');
  const files = readdirSync(eventsDir).filter(f => f.endsWith('.js'));
  for (const file of files) {
    try {
      const event = require(path.join(eventsDir, file));
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }
      console.log(`📡 Event: ${event.name}`);
    } catch (e) {
      console.error(`[EVENT] Erreur ${file}:`, e.message);
    }
  }
};
