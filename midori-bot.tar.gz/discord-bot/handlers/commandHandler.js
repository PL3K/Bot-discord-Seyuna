const { Collection } = require('discord.js');
const { readdirSync, statSync } = require('fs');
const path = require('path');

function loadCommands(dir, collection) {
  const entries = readdirSync(dir);
  for (const entry of entries) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) {
      loadCommands(full, collection);
    } else if (entry.endsWith('.js')) {
      try {
        const cmd = require(full);
        if (cmd.name) {
          collection.set(cmd.name, cmd);
          if (cmd.aliases) cmd.aliases.forEach(a => collection.set(a, cmd));
        }
      } catch (e) {
        console.error(`[CMD] Erreur chargement ${entry}:`, e.message);
      }
    }
  }
}

module.exports = (client) => {
  client.commands = new Collection();
  const cmdDir = path.join(__dirname, '..', 'commands');
  loadCommands(cmdDir, client.commands);
  console.log(`📦 ${client.commands.size} commandes chargées`);
};
