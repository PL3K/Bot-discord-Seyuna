const { EmbedBuilder } = require('discord.js');
const { marriages } = require('../../systems/database');

module.exports = {
  name: 'couple',
  description: 'Voir votre statut de couple',
  async execute(message, args, client) {
    const target = message.mentions.members.first() || message.member;
    const marriage = marriages.get.get(target.id, target.id, message.guild.id);
    if (!marriage) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`💔 ${target} n'est pas marié(e).`).setFooter({ text: '緑 • Midori 🌿' })] });
    const partnerId = marriage.user1_id === target.id ? marriage.user2_id : marriage.user1_id;
    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('💕 Couple')
      .setDescription(`💗 **${target.user.username}** est marié(e) avec <@${partnerId}>!\n📅 Depuis le: ${marriage.married_at}`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
