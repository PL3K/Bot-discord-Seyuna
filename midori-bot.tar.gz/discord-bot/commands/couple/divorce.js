const { EmbedBuilder } = require('discord.js');
const { marriages } = require('../../systems/database');

module.exports = {
  name: 'divorce',
  description: 'Divorcer de votre partenaire',
  async execute(message, args, client) {
    const marriage = marriages.get.get(message.author.id, message.author.id, message.guild.id);
    if (!marriage) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous n\'êtes pas marié(e).')] });
    marriages.remove.run(message.author.id, message.author.id, message.guild.id);
    const partner = marriage.user1_id === message.author.id ? marriage.user2_id : marriage.user1_id;
    message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('💔 Divorce').setDescription(`Vous avez divorcé de <@${partner}>. 💔`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
