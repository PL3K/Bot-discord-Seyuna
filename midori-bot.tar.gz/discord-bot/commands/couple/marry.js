const { EmbedBuilder } = require('discord.js');
const { marriages } = require('../../systems/database');

module.exports = {
  name: 'marry',
  description: 'Demander quelqu\'un en mariage',
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Mentionnez quelqu\'un à épouser.')] });
    if (target.id === message.author.id) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous ne pouvez pas vous marier avec vous-même.')] });
    if (target.user.bot) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous ne pouvez pas épouser un bot.')] });

    const existing = marriages.get.get(message.author.id, message.author.id, message.guild.id);
    if (existing) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous êtes déjà marié(e)! Utilisez `+divorce` d\'abord.')] });

    const targetMarried = marriages.get.get(target.id, target.id, message.guild.id);
    if (targetMarried) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`❌ ${target} est déjà marié(e).`)] });

    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('💍 Demande en Mariage')
      .setDescription(`💗 **${message.author.username}** demande ${target} en mariage!\n\n${target}, tapez **"oui"** pour accepter ou **"non"** pour refuser.`)
      .setFooter({ text: '緑 • Midori 🌿' });
    await message.reply({ embeds: [embed] });

    const filter = (m) => m.author.id === target.id && ['oui', 'non'].includes(m.content.toLowerCase());
    const collector = message.channel.createMessageCollector({ filter, time: 30000, max: 1 });

    collector.on('collect', (m) => {
      if (m.content.toLowerCase() === 'oui') {
        marriages.add.run(message.author.id, target.id, message.guild.id);
        message.channel.send({ embeds: [new EmbedBuilder().setColor('#FF69B4').setTitle('💒 Mariage!').setDescription(`🎊 **${message.author.username}** et **${target.user.username}** sont maintenant mariés! 💍❤️`).setFooter({ text: '緑 • Midori 🌿' })] });
      } else {
        message.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`💔 **${target.user.username}** a refusé la demande en mariage.`).setFooter({ text: '緑 • Midori 🌿' })] });
      }
    });

    collector.on('end', (collected) => {
      if (!collected.size) message.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('⏰ Temps écoulé. Demande en mariage expirée.')] }).catch(() => {});
    });
  },
};
