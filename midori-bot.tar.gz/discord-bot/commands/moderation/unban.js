const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'unban',
  description: 'Débannir un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('BanMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const userId = args[0];
    if (!userId) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez fournir un ID.')] });
    await message.guild.bans.remove(userId).catch(() => null);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ L'utilisateur \`${userId}\` a été débanni.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
