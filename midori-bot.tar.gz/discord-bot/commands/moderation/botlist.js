const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'botlist',
  description: 'Liste de tous les bots du serveur',
  async execute(message, args, client) {
    await message.guild.members.fetch().catch(() => {});
    const bots = message.guild.members.cache.filter(m => m.user.bot);
    const list = bots.map(m => `• ${m.user.tag} (\`${m.id}\`)`).join('\n') || 'Aucun';
    const embed = new EmbedBuilder().setColor('#5865F2').setTitle(`🤖 Bots — ${message.guild.name}`).setDescription(list).setFooter({ text: `Total: ${bots.size} | 緑 • Midori 🌿` });
    message.reply({ embeds: [embed] });
  },
};
