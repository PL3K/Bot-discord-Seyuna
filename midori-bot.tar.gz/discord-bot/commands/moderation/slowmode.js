const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'slowmode',
  description: 'Mettre en place un mode lent',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const seconds = parseInt(args[0]) || 0;
    if (seconds < 0 || seconds > 21600) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Valeur invalide (0–21600 secondes).')] });
    await message.channel.setRateLimitPerUser(seconds).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(seconds === 0 ? '✅ Slowmode désactivé.' : `✅ Slowmode réglé à **${seconds}** secondes.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
