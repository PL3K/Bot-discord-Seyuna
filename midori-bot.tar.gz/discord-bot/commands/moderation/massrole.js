const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'massrole',
  description: 'Attribuer ou retirer un rôle massivement',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const action = args[0]?.toLowerCase();
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
    if (!action || !role || !['add', 'remove'].includes(action)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+massrole add/remove @rôle`')] });
    const msg = await message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription(`⏳ En cours...`)] });
    await message.guild.members.fetch().catch(() => {});
    const humans = message.guild.members.cache.filter(m => !m.user.bot);
    let count = 0;
    for (const [, member] of humans) {
      if (action === 'add') await member.roles.add(role).catch(() => {});
      else await member.roles.remove(role).catch(() => {});
      count++;
    }
    msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Rôle ${role} ${action === 'add' ? 'ajouté à' : 'retiré de'} **${count}** membres.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
