const { EmbedBuilder } = require('discord.js');
const { warns } = require('../../systems/database');

module.exports = {
  name: 'unwarn',
  description: 'Retirer un avertissement',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const warnId = parseInt(args[0]);
    if (isNaN(warnId)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez fournir l\'ID du warn (voir `+warnlist`).')] });
    warns.remove.run(warnId, message.guild.id);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Warn \`#${warnId}\` retiré.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
