const { EmbedBuilder } = require('discord.js');
const { warns, getConfig } = require('../../systems/database');

module.exports = {
  name: 'warn',
  description: 'Avertir un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    const reason = args.slice(1).join(' ') || 'Aucune raison fournie';
    warns.add.run(target.id, message.guild.id, message.author.id, reason);
    const count = warns.count.get(target.id, message.guild.id)?.n || 0;
    const embed = new EmbedBuilder().setColor('#FEE75C').setTitle('⚠️ Avertissement').addFields(
      { name: '👤 Membre', value: target.user.tag, inline: true },
      { name: '👮 Modérateur', value: message.author.tag, inline: true },
      { name: '📝 Raison', value: reason, inline: false },
      { name: '🔢 Total warns', value: `${count}`, inline: true },
    ).setFooter({ text: '緑 • Midori 🌿' }).setTimestamp();
    message.reply({ embeds: [embed] });
    const cfg = getConfig(message.guild.id);
    if (cfg.mod_log) { const ch = message.guild.channels.cache.get(cfg.mod_log); if (ch) ch.send({ embeds: [embed] }).catch(() => {}); }
  },
};
