const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'emoji',
  description: 'Créer un emoji sur le serveur',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuildExpressions')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const name = args[0];
    const attachment = message.attachments.first();
    if (!name || !attachment) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+emoji <nom>` (avec une image en attachement)')] });
    const emoji = await message.guild.emojis.create({ attachment: attachment.url, name }).catch(e => null);
    if (!emoji) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Impossible de créer l\'emoji.')] });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Emoji ${emoji} créé!`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
