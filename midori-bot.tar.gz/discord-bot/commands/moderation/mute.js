const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'mute',
  description: 'Rendre muet un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    const cfg = getConfig(message.guild.id);
    if (cfg.mute_role) {
      await target.roles.add(cfg.mute_role).catch(() => {});
    } else {
      // Timeout 10 minutes par défaut
      await target.timeout(10 * 60 * 1000, args.slice(1).join(' ') || 'Mute').catch(() => {});
    }
    const reason = args.slice(1).join(' ') || 'Aucune raison fournie';
    const embed = new EmbedBuilder().setColor('#FEE75C').setTitle('🔇 Membre muet').addFields(
      { name: '👤 Membre', value: target.user.tag, inline: true },
      { name: '👮 Modérateur', value: message.author.tag, inline: true },
      { name: '📝 Raison', value: reason, inline: false },
    ).setFooter({ text: '緑 • Midori 🌿' }).setTimestamp();
    message.reply({ embeds: [embed] });
    if (cfg.mod_log) { const ch = message.guild.channels.cache.get(cfg.mod_log); if (ch) ch.send({ embeds: [embed] }).catch(() => {}); }
  },
};
