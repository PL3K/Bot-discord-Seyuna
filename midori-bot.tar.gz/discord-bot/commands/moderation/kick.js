const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'kick',
  description: 'Expulser un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('KickMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous n\'avez pas la permission de kick.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    if (!target.kickable) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Je ne peux pas kick ce membre.')] });
    const reason = args.slice(1).join(' ') || 'Aucune raison fournie';
    await target.kick(reason);
    const embed = new EmbedBuilder().setColor('#57F287').setTitle('👢 Membre expulsé').addFields(
      { name: '👤 Membre', value: target.user.tag, inline: true },
      { name: '👮 Modérateur', value: message.author.tag, inline: true },
      { name: '📝 Raison', value: reason, inline: false },
    ).setFooter({ text: '緑 • Midori 🌿' }).setTimestamp();
    message.reply({ embeds: [embed] });
    // Log
    const cfg = getConfig(message.guild.id);
    if (cfg.mod_log) { const ch = message.guild.channels.cache.get(cfg.mod_log); if (ch) ch.send({ embeds: [embed] }).catch(() => {}); }
  },
};
