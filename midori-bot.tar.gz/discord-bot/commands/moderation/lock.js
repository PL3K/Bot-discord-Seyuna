const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'lock',
  description: 'Fermer un salon',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const ch = message.channel;
    await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false }).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`🔒 Le salon ${ch} a été verrouillé.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
