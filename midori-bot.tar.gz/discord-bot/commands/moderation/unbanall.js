const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'unbanall',
  description: 'Débannir tous les membres',
  async execute(message, args, client) {
    if (!message.member.permissions.has('BanMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const bans = await message.guild.bans.fetch();
    if (bans.size === 0) return message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription('⚠️ Aucun ban à retirer.')] });
    let count = 0;
    for (const [id] of bans) { await message.guild.bans.remove(id).catch(() => {}); count++; }
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ **${count}** membre(s) débanni(s).`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
