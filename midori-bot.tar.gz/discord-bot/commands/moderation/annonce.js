const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'annonce',
  description: 'Faire une annonce de l\'administration',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez entrer un message.')] });
    await message.delete().catch(() => {});
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('📢 Annonce officielle')
      .setDescription(text)
      .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
      .setTimestamp()
      .setFooter({ text: `${message.guild.name} • Midori 🌿` });
    message.channel.send({ content: '@everyone', embeds: [embed] });
  },
};
