const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'unlockall',
  description: 'Ouvrir tous les salons',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const channels = message.guild.channels.cache.filter(c => c.type === 0);
    let count = 0;
    for (const [, ch] of channels) {
      await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }).catch(() => {});
      count++;
    }
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`🔓 **${count}** salons déverrouillés.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
