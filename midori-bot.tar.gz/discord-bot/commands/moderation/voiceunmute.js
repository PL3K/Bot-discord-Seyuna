const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'voiceunmute',
  description: 'Unmute un membre en vocal',
  async execute(message, args, client) {
    if (!message.member.permissions.has('MuteMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    await target.voice.setMute(false).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`🔊 ${target} peut parler en vocal.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
