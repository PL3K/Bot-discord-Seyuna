const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'unlock',
  description: 'Ouvrir un salon',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null }).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`🔓 Le salon ${message.channel} a été déverrouillé.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
