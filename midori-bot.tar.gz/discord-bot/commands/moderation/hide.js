const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'hide',
  description: 'Cacher un salon',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: false }).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`🙈 Salon caché.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
