const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'adminlist',
  description: 'Liste des membres avec la permission Administrateur',
  async execute(message, args, client) {
    await message.guild.members.fetch().catch(() => {});
    const admins = message.guild.members.cache.filter(m => !m.user.bot && m.permissions.has('Administrator'));
    const list = admins.map(m => `• ${m.user.tag} (\`${m.id}\`)`).join('\n') || 'Aucun';
    const embed = new EmbedBuilder().setColor('#5865F2').setTitle(`👑 Administrateurs — ${message.guild.name}`).setDescription(list).setFooter({ text: `Total: ${admins.size} | 緑 • Midori 🌿` });
    message.reply({ embeds: [embed] });
  },
};
