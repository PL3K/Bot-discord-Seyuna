const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'rlist',
  description: 'Liste des membres avec la permission Gérer les rôles',
  async execute(message, args, client) {
    await message.guild.members.fetch().catch(() => {});
    const members = message.guild.members.cache.filter(m => !m.user.bot && m.permissions.has('ManageRoles'));
    const list = members.map(m => `• ${m.user.tag} (\`${m.id}\`)`).join('\n') || 'Aucun';
    const embed = new EmbedBuilder().setColor('#5865F2').setTitle(`🎭 Gérer les Rôles — ${message.guild.name}`).setDescription(list).setFooter({ text: `Total: ${members.size} | 緑 • Midori 🌿` });
    message.reply({ embeds: [embed] });
  },
};
