const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'clear',
  aliases: ['purge'],
  description: 'Supprimer des messages',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageMessages')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount < 1 || amount > 100) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez spécifier un nombre entre 1 et 100.')] });
    await message.delete().catch(() => {});
    const deleted = await message.channel.bulkDelete(amount, true).catch(() => null);
    const embed = new EmbedBuilder().setColor('#57F287').setDescription(`🗑️ **${deleted?.size || 0}** message(s) supprimé(s).`).setFooter({ text: '緑 • Midori 🌿' });
    message.channel.send({ embeds: [embed] }).then(m => setTimeout(() => m.delete().catch(() => {}), 4000));
  },
};
