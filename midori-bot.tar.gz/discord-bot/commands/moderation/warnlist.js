const { EmbedBuilder } = require('discord.js');
const { warns } = require('../../systems/database');

module.exports = {
  name: 'warnlist',
  description: 'Voir les avertissements d\'un membre',
  async execute(message, args, client) {
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null) || message.member;
    const list = warns.get.all(target.id, message.guild.id);
    if (!list.length) return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ ${target} n'a aucun avertissement.`)] });
    const desc = list.map(w => `**#${w.id}** — ${w.reason} — par <@${w.moderator_id}> — ${w.created_at}`).join('\n');
    const embed = new EmbedBuilder().setColor('#FEE75C').setTitle(`⚠️ Avertissements — ${target.user.tag}`).setDescription(desc).setFooter({ text: `Total: ${list.length} | 緑 • Midori 🌿` });
    message.reply({ embeds: [embed] });
  },
};
