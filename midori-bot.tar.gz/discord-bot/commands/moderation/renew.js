const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'renew',
  description: 'Recréer un salon à l\'identique',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const ch = message.channel;
    const position = ch.position;
    const parent = ch.parentId;
    const name = ch.name;
    const topic = ch.topic;
    const overwrites = ch.permissionOverwrites.cache;
    const newCh = await message.guild.channels.create({ name, topic, parent, permissionOverwrites: overwrites }).catch(() => null);
    if (!newCh) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Impossible de recréer le salon.')] });
    await newCh.setPosition(position).catch(() => {});
    await ch.delete().catch(() => {});
    newCh.send({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Salon recréé à l\'identique.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
