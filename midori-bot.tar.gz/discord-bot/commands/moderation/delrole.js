const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'delrole',
  description: 'Retirer un rôle à un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageRoles')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
    if (!target || !role) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+delrole @membre @rôle`')] });
    await target.roles.remove(role).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Rôle ${role} retiré de ${target}.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
