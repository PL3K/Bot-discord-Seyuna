const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'unmute',
  description: 'Redonner la parole à un membre',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ModerateMembers')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    const cfg = getConfig(message.guild.id);
    if (cfg.mute_role) await target.roles.remove(cfg.mute_role).catch(() => {});
    await target.timeout(null).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ ${target} peut de nouveau parler.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
