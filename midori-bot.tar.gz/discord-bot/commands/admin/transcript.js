const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

module.exports = {
  name: 'transcript',
  description: 'Récupérer tous les messages d\'un salon',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageMessages')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const msgs = await message.channel.messages.fetch({ limit: 100 });
    const sorted = msgs.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    const content = sorted.map(m => `[${new Date(m.createdTimestamp).toLocaleString('fr-FR')}] ${m.author.tag}: ${m.content || '[Embed/Fichier]'}`).join('\n');
    const buffer = Buffer.from(content, 'utf-8');
    const attach = new AttachmentBuilder(buffer, { name: `transcript-${message.channel.name}.txt` });
    message.reply({ content: '📝 Transcript généré!', files: [attach] });
  },
};
