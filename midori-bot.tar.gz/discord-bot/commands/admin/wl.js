const { EmbedBuilder } = require('discord.js');
const { whitelist } = require('../../systems/database');

module.exports = {
  name: 'wl',
  aliases: ['whitelist'],
  description: 'Gérer la whitelist antiraid',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const sub = args[0]?.toLowerCase();
    if (sub === 'list') {
      const list = whitelist.getAll.all(message.guild.id);
      const desc = list.length ? list.map(w => `• <@${w.user_id}>`).join('\n') : 'Aucun membre en whitelist.';
      return message.reply({ embeds: [new EmbedBuilder().setColor('#5865F2').setTitle('📋 Whitelist').setDescription(desc).setFooter({ text: `Total: ${list.length} | 緑 • Midori 🌿` })] });
    }
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+wl @membre` ou `+wl list`')] });
    const isWl = whitelist.check.get(target.id, message.guild.id);
    if (isWl) {
      whitelist.remove.run(target.id, message.guild.id);
      message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`✅ ${target} retiré de la whitelist.`).setFooter({ text: '緑 • Midori 🌿' })] });
    } else {
      whitelist.add.run(target.id, message.guild.id, message.author.id);
      message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ ${target} ajouté à la whitelist.`).setFooter({ text: '緑 • Midori 🌿' })] });
    }
  },
};
