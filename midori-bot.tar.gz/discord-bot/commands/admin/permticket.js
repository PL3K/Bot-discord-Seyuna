const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'permticket',
  description: 'Configurer le rôle qui aura accès aux tickets',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
    if (!role) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Rôle introuvable.')] });
    upsertConfig(message.guild.id, { ticket_role: role.id });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Rôle ticket configuré: ${role}`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
