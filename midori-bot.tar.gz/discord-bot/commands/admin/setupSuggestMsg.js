const { EmbedBuilder } = require('discord.js');
const { upsertConfig, getConfig } = require('../../systems/database');

module.exports = {
  name: 'setupsuggestmsg',
  aliases: ['setupSuggestMsg'],
  description: 'Configurer le message du module suggestion',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const cfg = getConfig(message.guild.id);
    if (!cfg.suggest_channel) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Configurez d\'abord un salon avec `+setsuggest`.')] });
    const ch = message.guild.channels.cache.get(cfg.suggest_channel);
    if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Salon de suggestions introuvable.')] });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('💡 Suggestions — ' + message.guild.name)
      .setDescription('Utilisez `+suggest <votre suggestion>` pour soumettre une suggestion.\n\nVotez pour les suggestions avec ✅ ou ❌!')
      .setFooter({ text: `${message.guild.name} • Midori 🌿` })
      .setTimestamp();
    await ch.send({ embeds: [embed] });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Message de suggestions envoyé dans ${ch}!`)] });
  },
};
