const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'config',
  description: 'Afficher la configuration du bot sur le serveur',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const cfg = getConfig(message.guild.id);
    const ch = (id) => id ? `<#${id}>` : '`Non configuré`';
    const rl = (id) => id ? `<@&${id}>` : '`Non configuré`';
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`⚙️ Configuration — ${message.guild.name}`)
      .addFields(
        { name: '📌 Préfixe', value: `\`${cfg.prefix || '+'}\``, inline: true },
        { name: '🔇 Rôle Muet', value: rl(cfg.mute_role), inline: true },
        { name: '🎭 Rôle Auto', value: rl(cfg.auto_role), inline: true },
        { name: '📋 Mod Log', value: ch(cfg.mod_log), inline: true },
        { name: '💬 Message Log', value: ch(cfg.message_log), inline: true },
        { name: '🎟️ Ticket Log', value: ch(cfg.ticket_log), inline: true },
        { name: '🎊 Giveaway Log', value: ch(cfg.giveaway_log), inline: true },
        { name: '💎 Boost Log', value: ch(cfg.boost_log), inline: true },
        { name: '🛡️ Raid Log', value: ch(cfg.raid_log), inline: true },
        { name: '💡 Suggestions', value: ch(cfg.suggest_channel), inline: true },
        { name: '🎟️ Catégorie Tickets', value: ch(cfg.ticket_category), inline: true },
        { name: '👋 Bienvenue', value: ch(cfg.welcome_channel), inline: true },
        { name: '🛡️ Antiraid', value: cfg.antiraid_enabled ? '✅ Actif' : '❌ Inactif', inline: true },
        { name: '🔗 Antilink', value: `\`${cfg.antilink || 'off'}\``, inline: true },
        { name: '⚡ Punition', value: `\`${cfg.punition || 'kick'}\``, inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
