const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'prefix',
  description: 'Changer le préfixe du bot',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const newPrefix = args[0];
    if (!newPrefix || newPrefix.length > 5) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Préfixe invalide (1-5 caractères).')] });
    upsertConfig(message.guild.id, { prefix: newPrefix });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Préfixe changé en \`${newPrefix}\``).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
