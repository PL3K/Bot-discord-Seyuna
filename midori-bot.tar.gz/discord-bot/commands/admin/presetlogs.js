const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'presetlogs',
  description: 'Créer et configurer automatiquement tous les salons logs',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const msg = await message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription('⏳ Création des salons logs...')] });

    const logTypes = [
      { name: '📋・mod-log', key: 'mod_log' },
      { name: '💬・message-log', key: 'message_log' },
      { name: '🎟️・ticket-log', key: 'ticket_log' },
      { name: '🎊・giveaway-log', key: 'giveaway_log' },
      { name: '💎・boost-log', key: 'boost_log' },
      { name: '🛡️・raid-log', key: 'raid_log' },
    ];

    // Trouver ou créer une catégorie "Logs"
    let category = message.guild.channels.cache.find(c => c.type === 4 && c.name.toLowerCase().includes('log'));
    if (!category) {
      category = await message.guild.channels.create({ name: '📊 Logs', type: 4 }).catch(() => null);
    }

    const updates = {};
    for (const log of logTypes) {
      const existing = message.guild.channels.cache.find(c => c.name === log.name.toLowerCase().replace(/[^a-z0-9-]/g, ''));
      if (existing) {
        updates[log.key] = existing.id;
      } else {
        const ch = await message.guild.channels.create({
          name: log.name,
          type: 0,
          parent: category?.id,
          permissionOverwrites: [{ id: message.guild.roles.everyone, deny: ['ViewChannel'] }],
        }).catch(() => null);
        if (ch) updates[log.key] = ch.id;
      }
    }

    upsertConfig(message.guild.id, updates);
    msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('✅ Logs configurés!').setDescription(Object.entries(updates).map(([k, v]) => `• **${k}**: <#${v}>`).join('\n')).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
