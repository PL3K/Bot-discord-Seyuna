const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'embed',
  description: 'Créer un embed',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageMessages')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+embed <titre> | <description> | <couleur>`\nExemple: `+embed Mon titre | Ma description | #FF0000`')] });
    const parts = text.split('|').map(p => p.trim());
    const title = parts[0] || 'Embed';
    const desc = parts[1] || '';
    const color = parts[2] || '#5865F2';
    await message.delete().catch(() => {});
    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(title)
      .setDescription(desc)
      .setFooter({ text: `${message.guild.name} • Midori 🌿` })
      .setTimestamp();
    message.channel.send({ embeds: [embed] });
  },
};
