const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

module.exports = {
  name: 'backup',
  description: 'Créer une sauvegarde du serveur (Salons, Rôles)',
  async execute(message, args, client) {
    if (message.author.id !== message.guild.ownerId && !message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Réservé au propriétaire du serveur.')] });
    const msg = await message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription('⏳ Création de la sauvegarde...')] });

    const backup = {
      name: message.guild.name,
      icon: message.guild.iconURL({ dynamic: true }),
      createdAt: new Date().toISOString(),
      roles: message.guild.roles.cache.filter(r => !r.managed && r.id !== message.guild.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor, permissions: r.permissions.toArray(), hoist: r.hoist, mentionable: r.mentionable, position: r.position })),
      channels: message.guild.channels.cache.map(ch => ({ id: ch.id, name: ch.name, type: ch.type, parentId: ch.parentId, position: ch.position })),
      memberCount: message.guild.memberCount,
    };

    const buf = Buffer.from(JSON.stringify(backup, null, 2), 'utf-8');
    const attach = new AttachmentBuilder(buf, { name: `backup-${message.guild.name}-${Date.now()}.json` });
    msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Sauvegarde créée!')], files: [attach] });
  },
};
