const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { db } = require('../../systems/database');

module.exports = {
  name: 'buttonrole',
  description: 'Créer un embed bouton pour avoir un rôle',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageRoles')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const role = message.mentions.roles.first();
    const description = args.slice(1).join(' ');
    if (!role || !description) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+buttonrole @rôle <description>`')] });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🎭 Attribution de Rôle')
      .setDescription(`${description}\n\nCliquez sur le bouton pour obtenir/retirer le rôle ${role}.`)
      .setFooter({ text: `${message.guild.name} • Midori 🌿` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`buttonrole_${role.id}`)
        .setLabel(`✨ ${role.name}`)
        .setStyle(ButtonStyle.Primary)
    );

    const sent = await message.channel.send({ embeds: [embed], components: [row] });
    db.prepare('INSERT INTO button_roles (message_id, guild_id, role_id, description) VALUES (?, ?, ?, ?)').run(sent.id, message.guild.id, role.id, description);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Bouton rôle créé pour ${role}!`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
