const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'setcategorie',
  description: 'Sélectionner la catégorie des tickets',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const cat = message.guild.channels.cache.get(args[0]);
    if (!cat || cat.type !== 4) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Catégorie invalide. Fournissez l\'ID d\'une catégorie.')] });
    upsertConfig(message.guild.id, { ticket_category: cat.id });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Catégorie des tickets: **${cat.name}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
