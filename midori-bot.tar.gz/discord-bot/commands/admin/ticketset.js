const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { upsertConfig, getConfig } = require('../../systems/database');

module.exports = {
  name: 'ticketset',
  description: 'Créer un système ticket pré-défini (Public)',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🎟️ Système de Tickets')
      .setDescription('Cliquez sur le bouton ci-dessous pour ouvrir un ticket.\nNotre équipe vous répondra dès que possible.')
      .setFooter({ text: `${message.guild.name} • Midori 🌿` })
      .setTimestamp();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_create').setLabel('📩 Ouvrir un Ticket').setStyle(ButtonStyle.Primary)
    );
    message.channel.send({ embeds: [embed], components: [row] });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Système de tickets créé!')] });
  },
};
