const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'vote',
  description: 'Voter pour le bot',
  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('⭐ Voter pour Midori 🌿')
      .setDescription('Merci de soutenir le bot! Votez pour nous sur top.gg:\n[Voter ici](https://top.gg)')
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
