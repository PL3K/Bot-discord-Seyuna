const { EmbedBuilder } = require('discord.js');
const { snipe } = require('../../systems/database');

module.exports = {
  name: 'snipe',
  description: 'Afficher le dernier message supprimé',
  async execute(message, args, client) {
    const data = snipe.get.get(message.channel.id);
    if (!data) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Aucun message supprimé récemment dans ce salon.')] });

    const user = await client.users.fetch(data.author_id).catch(() => null);
    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('🔍 Dernier message supprimé')
      .setDescription(data.content)
      .addFields(
        { name: '👤 Auteur', value: user ? user.toString() : data.author_id, inline: true },
        { name: '📅 Supprimé', value: data.deleted_at, inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
