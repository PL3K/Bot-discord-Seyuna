const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'find',
  description: 'Chercher un membre en vocal',
  async execute(message, args, client) {
    let target = message.mentions.members.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null);

    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });

    const vc = target.voice?.channel;
    if (!vc) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`❌ ${target} n'est pas dans un salon vocal.`)] });

    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setDescription(`🔍 ${target} est dans **${vc.name}** avec ${vc.members.size} membres.`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
