const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'confess',
  description: 'Envoyer un message anonyme',
  async execute(message, args, client) {
    const text = args.join(' ');
    if (!text) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez entrer un message.')] });

    message.delete().catch(() => {});

    const embed = new EmbedBuilder()
      .setColor('#9B59B6')
      .setTitle('💭 Confession Anonyme')
      .setDescription(text)
      .setTimestamp()
      .setFooter({ text: '緑 • Midori 🌿 — Message anonyme' });

    message.channel.send({ embeds: [embed] });
  },
};
