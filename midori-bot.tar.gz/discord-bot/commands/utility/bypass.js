const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'bypass',
  description: 'Voir quel antiraid est bypass par quel niveau de permission',
  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🛡️ Bypass Antiraid — Midori 🌿')
      .setDescription(
        '**Niveaux de bypass antiraid:**\n\n' +
        '`Owner` → Bypass **tout** l\'antiraid\n' +
        '`Whitelist` → Bypass **tout** l\'antiraid\n' +
        '`Administrator` → Bypass antispam, antilink (selon config)\n' +
        '`Moderator (Ban/Kick)` → Bypass certaines protections\n\n' +
        '**Whitelist:** Utilisez `+wl @membre` pour ajouter un membre à la whitelist.\n' +
        '**Punition:** Configurez avec `+punition` (kick, ban, mute).'
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
