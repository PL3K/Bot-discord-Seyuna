const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'invite',
  description: 'Inviter le bot',
  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('📨 Inviter Midori 🌿')
      .setDescription(`[Cliquez ici pour inviter le bot](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8)`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
