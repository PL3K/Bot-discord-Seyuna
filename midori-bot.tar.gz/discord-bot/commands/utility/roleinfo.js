const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'roleinfo',
  aliases: ['ri'],
  description: 'Informations sur un rôle',
  async execute(message, args, client) {
    const role = message.mentions.roles.first() ||
      message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase()) ||
      message.guild.roles.cache.get(args[0]);

    if (!role) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Rôle introuvable.')] });

    const members = message.guild.members.cache.filter(m => m.roles.cache.has(role.id)).size;
    const embed = new EmbedBuilder()
      .setColor(role.color || '#2b2d31')
      .setTitle(`Rôle — ${role.name}`)
      .addFields(
        { name: '🆔 ID', value: role.id, inline: true },
        { name: '🎨 Couleur', value: role.hexColor, inline: true },
        { name: '👥 Membres', value: `${members}`, inline: true },
        { name: '📅 Créé le', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '📌 Position', value: `${role.position}`, inline: true },
        { name: '🔔 Mentionnable', value: role.mentionable ? 'Oui' : 'Non', inline: true },
        { name: '🔒 Séparé', value: role.hoist ? 'Oui' : 'Non', inline: true },
        { name: '⚙️ Géré', value: role.managed ? 'Oui' : 'Non', inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
