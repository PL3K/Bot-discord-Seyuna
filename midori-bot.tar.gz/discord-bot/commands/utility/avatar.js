const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'avatar',
  aliases: ['av', 'pfp'],
  description: 'Obtenir l\'avatar d\'un membre',
  async execute(message, args, client) {
    let target = message.mentions.users.first() ||
      (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null) ||
      message.author;

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`Avatar de ${target.username}`)
      .setImage(target.displayAvatarURL({ dynamic: true, size: 1024 }))
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
