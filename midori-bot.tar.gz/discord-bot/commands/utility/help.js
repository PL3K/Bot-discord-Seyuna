const { EmbedBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ActionRowBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'help',
  aliases: ['aide', 'h'],
  description: 'Panel d\'aide Midori',
  async execute(message, args, client) {
    const cfg = getConfig(message.guild.id);
    const prefix = cfg.prefix || '+';

    if (args[0] === 'msg') {
      const embed = new EmbedBuilder()
        .setColor('#2b2d31')
        .setTitle('📨 Variables Messages')
        .setDescription(
          '**Variables disponibles pour les messages configurables:**\n\n' +
          '`{user}` — Mention de l\'utilisateur\n' +
          '`{user.name}` — Nom de l\'utilisateur\n' +
          '`{user.id}` — ID de l\'utilisateur\n' +
          '`{user.tag}` — Tag de l\'utilisateur\n' +
          '`{server}` — Nom du serveur\n' +
          '`{server.id}` — ID du serveur\n' +
          '`{server.members}` — Nombre de membres\n' +
          '`{channel}` — Nom du salon actuel\n' +
          '`{date}` — Date actuelle\n' +
          '`{prefix}` — Préfixe actuel'
        )
        .setFooter({ text: `緑 • Midori 🌿 • Préfixe actuel : ${prefix}` });
      return message.reply({ embeds: [embed] });
    }

    const mainEmbed = new EmbedBuilder()
      .setColor('#2b2d31')
      .setTitle('緑 • Panel d\'aide de ' + message.guild.name)
      .setDescription(
        `**🎋 Midori 🌿 • みどり**\n\n` +
        `⛩️ Bienvenue sur **Midori 🌿**\n` +
        `🔎 Ce bot appartient à **${message.guild.name}**\n` +
        `🔍 Préfixe actuel : **${prefix}**\n\n` +
        `🌿 • Choisissez une catégorie ci-dessous pour explorer les commandes.`
      )
      .setImage('https://i.imgur.com/HZ8JQyp.png')
      .setFooter({ text: `緑 • Midori 🌿 • Préfixe actuel : ${prefix}` });

    const menu = new StringSelectMenuBuilder()
      .setCustomId('help_category')
      .setPlaceholder('🌿 Choisissez une catégorie')
      .addOptions([
        new StringSelectMenuOptionBuilder().setLabel('Accueil').setDescription('Page d\'accueil du panel').setValue('home').setEmoji('⛩️'),
        new StringSelectMenuOptionBuilder().setLabel('Premium').setDescription('Commandes Premium').setValue('premium').setEmoji('🌸'),
        new StringSelectMenuOptionBuilder().setLabel('Antiraid').setDescription('Configuration de l\'Antiraid').setValue('antiraid').setEmoji('⚔️'),
        new StringSelectMenuOptionBuilder().setLabel('Gestion Permission').setDescription('Permet de contrôler les permissions du serveur').setValue('gestionperm').setEmoji('📚'),
        new StringSelectMenuOptionBuilder().setLabel('Utilitaire').setDescription('Commandes Public').setValue('utilitaire').setEmoji('🎮'),
        new StringSelectMenuOptionBuilder().setLabel('Modération').setDescription('Commandes de modération').setValue('moderation').setEmoji('🛡️'),
        new StringSelectMenuOptionBuilder().setLabel('Logs').setDescription('Logs du serveur').setValue('logs').setEmoji('📋'),
        new StringSelectMenuOptionBuilder().setLabel('Giveaway').setDescription('Commandes Giveaway').setValue('giveaway').setEmoji('🎊'),
        new StringSelectMenuOptionBuilder().setLabel('Jeux & Fun').setDescription('Jeux & Fun').setValue('jeux').setEmoji('🎯'),
        new StringSelectMenuOptionBuilder().setLabel('Activity').setDescription('Activity Together').setValue('activity').setEmoji('🎮'),
        new StringSelectMenuOptionBuilder().setLabel('Vocal').setDescription('Vocal & Temporaire').setValue('vocal').setEmoji('🔊'),
        new StringSelectMenuOptionBuilder().setLabel('Configuration').setDescription('Configuration & Outils (Admins)').setValue('config').setEmoji('⚙️'),
      ]);

    const row = new ActionRowBuilder().addComponents(menu);
    message.reply({ embeds: [mainEmbed], components: [row] });
  },
};
