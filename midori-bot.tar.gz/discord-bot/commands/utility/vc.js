const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'vc',
  description: 'Statistiques du serveur (Vocaux, Membres)',
  async execute(message, args, client) {
    const guild = message.guild;
    await guild.members.fetch().catch(() => {});
    const members = guild.memberCount;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const humans = members - bots;
    const online = guild.members.cache.filter(m => m.presence?.status === 'online').size;
    const inVoice = guild.members.cache.filter(m => m.voice?.channel).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`📊 Statistiques — ${guild.name}`)
      .addFields(
        { name: '👥 Membres total', value: `${members}`, inline: true },
        { name: '🧑 Humains', value: `${humans}`, inline: true },
        { name: '🤖 Bots', value: `${bots}`, inline: true },
        { name: '🟢 En ligne', value: `${online}`, inline: true },
        { name: '🔊 En vocal', value: `${inVoice}`, inline: true },
        { name: '📡 Salons vocaux', value: `${voiceChannels}`, inline: true },
      )
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
