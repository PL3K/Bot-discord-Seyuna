const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'userinfo',
  aliases: ['ui', 'whois'],
  description: 'Informations sur un utilisateur',
  async execute(message, args, client) {
    let member = message.mentions.members.first() ||
      (args[0] ? await message.guild.members.fetch(args[0]).catch(() => null) : null) ||
      message.member;

    const user = member.user;
    const roles = member.roles.cache.filter(r => r.id !== message.guild.id).map(r => r.toString()).join(', ') || 'Aucun';

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`Informations — ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🆔 ID', value: user.id, inline: true },
        { name: '🤖 Bot', value: user.bot ? 'Oui' : 'Non', inline: true },
        { name: '📅 Compte créé', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '📥 A rejoint', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        { name: '🎭 Rôles', value: roles.slice(0, 1024), inline: false },
        { name: '⚡ Statut', value: member.presence?.status || 'offline', inline: true },
        { name: '🎨 Couleur rôle', value: member.displayHexColor || '#000000', inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
