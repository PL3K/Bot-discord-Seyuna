const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../../systems/database');

module.exports = {
  name: 'suggest',
  description: 'Faire une suggestion sur le serveur',
  async execute(message, args, client) {
    const cfg = getConfig(message.guild.id);
    if (!cfg.suggest_channel) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Aucun salon de suggestions configuré. Utilisez `+setsuggest #salon`.')] });

    const suggestion = args.join(' ');
    if (!suggestion) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez entrer une suggestion.')] });

    const ch = message.guild.channels.cache.get(cfg.suggest_channel);
    if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Salon de suggestions introuvable.')] });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('💡 Nouvelle Suggestion')
      .setDescription(suggestion)
      .addFields({ name: '👤 Auteur', value: message.author.tag, inline: true })
      .setTimestamp()
      .setFooter({ text: '緑 • Midori 🌿' });

    const sent = await ch.send({ embeds: [embed] });
    await sent.react('✅').catch(() => {});
    await sent.react('❌').catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Votre suggestion a été envoyée dans ${ch}!`)] });
  },
};
