const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'banner',
  description: 'Bannière d\'un membre',
  async execute(message, args, client) {
    let target = message.mentions.users.first() ||
      (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null) ||
      message.author;

    const user = await client.users.fetch(target.id, { force: true });
    const bannerURL = user.bannerURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`Bannière de ${user.username}`)
      .setFooter({ text: '緑 • Midori 🌿' });

    if (bannerURL) embed.setImage(bannerURL);
    else embed.setDescription('❌ Cet utilisateur n\'a pas de bannière.');
    message.reply({ embeds: [embed] });
  },
};
