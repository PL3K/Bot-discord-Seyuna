const { EmbedBuilder } = require('discord.js');
const os = require('os');

module.exports = {
  name: 'stats',
  description: 'Statistiques du bot',
  async execute(message, args, client) {
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    const mem = process.memoryUsage();
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('📊 Statistiques — Midori 🌿')
      .addFields(
        { name: '⏱️ Uptime', value: `${h}h ${m}m ${s}s`, inline: true },
        { name: '📡 Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: '🖥️ Serveurs', value: `${client.guilds.cache.size}`, inline: true },
        { name: '👥 Utilisateurs', value: `${client.users.cache.size}`, inline: true },
        { name: '🗂️ Commandes', value: `${client.commands.size}`, inline: true },
        { name: '💾 RAM', value: `${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
        { name: '🔧 Node.js', value: process.version, inline: true },
        { name: '📚 discord.js', value: `v14`, inline: true },
      )
      .setThumbnail(client.user.displayAvatarURL())
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
