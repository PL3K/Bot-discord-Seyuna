const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Ping du bot',
  async execute(message, args, client) {
    const embed = new EmbedBuilder()
      .setColor('#57F287')
      .setTitle('🏓 Pong!')
      .addFields(
        { name: '📡 Latence Bot', value: `\`${client.ws.ping}ms\``, inline: true },
        { name: '⚡ Latence API', value: `\`${Date.now() - message.createdTimestamp}ms\``, inline: true }
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
