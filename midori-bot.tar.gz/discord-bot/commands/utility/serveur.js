const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'serveur',
  aliases: ['server', 'si'],
  description: 'Informations sur le serveur',
  async execute(message, args, client) {
    const guild = message.guild;
    const sub = args[0]?.toLowerCase();

    if (sub === 'pic') {
      const iconURL = guild.iconURL({ dynamic: true, size: 1024 });
      if (!iconURL) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Ce serveur n\'a pas de photo.')] });
      return message.reply({ embeds: [new EmbedBuilder().setColor('#5865F2').setTitle(`Photo de ${guild.name}`).setImage(iconURL).setFooter({ text: '緑 • Midori 🌿' })] });
    }

    if (sub === 'banner') {
      const bannerURL = guild.bannerURL({ dynamic: true, size: 1024 });
      if (!bannerURL) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Ce serveur n\'a pas de bannière.')] });
      return message.reply({ embeds: [new EmbedBuilder().setColor('#5865F2').setTitle(`Bannière de ${guild.name}`).setImage(bannerURL).setFooter({ text: '緑 • Midori 🌿' })] });
    }

    // info
    const owner = await guild.fetchOwner().catch(() => null);
    const channels = guild.channels.cache;
    const textCount = channels.filter(c => c.type === 0).size;
    const voiceCount = channels.filter(c => c.type === 2).size;
    const roles = guild.roles.cache.size;
    const members = guild.memberCount;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const boostLevel = guild.premiumTier;
    const boosts = guild.premiumSubscriptionCount;

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: '👑 Propriétaire', value: owner ? owner.user.tag : 'Inconnu', inline: true },
        { name: '📅 Créé le', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '🆔 ID', value: guild.id, inline: true },
        { name: '👥 Membres', value: `Total: ${members} | Bots: ${bots} | Humains: ${members - bots}`, inline: false },
        { name: '📝 Salons', value: `Textuels: ${textCount} | Vocaux: ${voiceCount} | Total: ${channels.size}`, inline: false },
        { name: '🎭 Rôles', value: `${roles}`, inline: true },
        { name: '💎 Boosts', value: `Niveau ${boostLevel} (${boosts} boosts)`, inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' })
      .setTimestamp();
    message.reply({ embeds: [embed] });
  },
};
