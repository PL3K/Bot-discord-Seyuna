const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'pviewc',
  description: 'Désactiver les permissions voir les salons du @everyone',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const everyone = message.guild.roles.everyone;
    await everyone.setPermissions(everyone.permissions.remove(PermissionsBitField.Flags.ViewChannel)).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Permission **Voir les salons** retirée du @everyone.').setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
