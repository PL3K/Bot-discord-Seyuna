const { EmbedBuilder } = require('discord.js');

const PERMS = {
  Administrator: 'Administrateur', ManageGuild: 'Gérer le serveur', ManageRoles: 'Gérer les rôles',
  ManageChannels: 'Gérer les salons', ManageMessages: 'Gérer les messages',
  KickMembers: 'Kick', BanMembers: 'Ban', MuteMembers: 'Mute membres',
  MoveMembers: 'Déplacer membres', ManageWebhooks: 'Gérer webhooks',
  ViewAuditLog: 'Voir l\'audit', MentionEveryone: 'Mention @everyone',
  ManageNicknames: 'Gérer les pseudos', ManageExpressions: 'Gérer les emojis',
};

module.exports = {
  name: 'perm',
  description: 'Afficher les permissions d\'un membre',
  async execute(message, args, client) {
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null) || message.member;
    const permsActive = Object.entries(PERMS).filter(([p]) => target.permissions.has(p)).map(([, name]) => `✅ ${name}`);
    const permsInactive = Object.entries(PERMS).filter(([p]) => !target.permissions.has(p)).map(([, name]) => `❌ ${name}`);
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`🔐 Permissions — ${target.user.tag}`)
      .addFields(
        { name: 'Actives', value: permsActive.join('\n') || 'Aucune', inline: true },
        { name: 'Inactives', value: permsInactive.join('\n') || 'Aucune', inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
