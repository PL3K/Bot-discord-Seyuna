const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'padmin',
  description: 'Désactiver les permissions administrateur du @everyone',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const everyone = message.guild.roles.everyone;
    const current = everyone.permissions;
    await everyone.setPermissions(current.remove(PermissionsBitField.Flags.Administrator)).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Permission **Administrateur** retirée du @everyone.').setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
