const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'pwebhooks',
  description: 'Désactiver les permissions webhooks du @everyone',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const everyone = message.guild.roles.everyone;
    await everyone.setPermissions(everyone.permissions.remove(PermissionsBitField.Flags.ManageWebhooks)).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Permission **Webhooks** retirée du @everyone.').setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
