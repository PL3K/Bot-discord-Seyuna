const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'pvoc',
  description: 'Désactiver les permissions vocal du @everyone',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const everyone = message.guild.roles.everyone;
    await everyone.setPermissions(everyone.permissions.remove([PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak, PermissionsBitField.Flags.MuteMembers, PermissionsBitField.Flags.DeafenMembers, PermissionsBitField.Flags.MoveMembers])).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Permissions **Vocal** retirées du @everyone.').setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
