const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'gestion',
  description: 'Afficher les différents modules de gestion',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('📚 Modules de Gestion — Midori 🌿')
      .addFields(
        { name: '🛡️ Antiraid', value: '`+secur` `+secur on/off` `+punition`', inline: false },
        { name: '🔐 Permissions', value: '`+perm` `+pall` `+padmin` `+prole` `+pban` `+pkick`', inline: false },
        { name: '📋 Logs', value: '`+presetlogs` `+modlog` `+messagelog` `+ticketlog`', inline: false },
        { name: '🎟️ Tickets', value: '`+ticketset` `+permticket` `+setcategorie`', inline: false },
        { name: '⚙️ Config', value: '`+config` `+prefix` `+muterole` `+wl`', inline: false },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
