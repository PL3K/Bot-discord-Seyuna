const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  name: 'pall',
  description: 'Désactiver toutes les permissions du serveur',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const everyone = message.guild.roles.everyone;
    await everyone.setPermissions([]).catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Toutes les permissions du rôle @everyone ont été désactivées.').setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
