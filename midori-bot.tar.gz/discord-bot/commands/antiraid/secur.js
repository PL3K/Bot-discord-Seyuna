const { EmbedBuilder } = require('discord.js');
const { getConfig, upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'secur',
  description: 'Configurer les protections de l\'antiraid',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const sub = args[0]?.toLowerCase();
    const cfg = getConfig(message.guild.id);

    if (sub === 'on') {
      upsertConfig(message.guild.id, { antiraid_enabled: 1, antiadmin: 1, antiban: 1, antibot: 1, antichannel_create: 1, antichannel_delete: 1, antichannel_update: 1, antirole_create: 1, antirole_delete: 1, antirole_update: 1, antiwebhook: 1, antidown: 1, antiupdate: 1 });
      return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🛡️ Antiraid ACTIVÉ').setDescription('Toutes les protections antiraid ont été activées.').setFooter({ text: '緑 • Midori 🌿' })] });
    }
    if (sub === 'off') {
      upsertConfig(message.guild.id, { antiraid_enabled: 0, antiadmin: 0, antiban: 0, antibot: 0, antichannel_create: 0, antichannel_delete: 0, antichannel_update: 0, antirole_create: 0, antirole_delete: 0, antirole_update: 0, antiwebhook: 0, antidown: 0, antiupdate: 0 });
      return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('🛡️ Antiraid DÉSACTIVÉ').setDescription('Toutes les protections antiraid ont été désactivées.').setFooter({ text: '緑 • Midori 🌿' })] });
    }

    // Afficher le statut
    const s = (v) => v ? '✅ Actif' : '❌ Inactif';
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🛡️ Configuration Antiraid')
      .setDescription(`**Status global:** ${s(cfg.antiraid_enabled)}\n\nUtilisez \`+secur on\` ou \`+secur off\` pour activer/désactiver tout.`)
      .addFields(
        { name: '👑 Anti Admin', value: s(cfg.antiadmin), inline: true },
        { name: '🔨 Anti Ban', value: s(cfg.antiban), inline: true },
        { name: '🤖 Anti Bot', value: s(cfg.antibot), inline: true },
        { name: '📝 Anti Channel Create', value: s(cfg.antichannel_create), inline: true },
        { name: '🗑️ Anti Channel Delete', value: s(cfg.antichannel_delete), inline: true },
        { name: '✏️ Anti Channel Update', value: s(cfg.antichannel_update), inline: true },
        { name: '🎭 Anti Role Create', value: s(cfg.antirole_create), inline: true },
        { name: '❌ Anti Role Delete', value: s(cfg.antirole_delete), inline: true },
        { name: '🔗 Anti Webhook', value: s(cfg.antiwebhook), inline: true },
        { name: '🔗 Anti Link', value: `\`${cfg.antilink || 'off'}\``, inline: true },
        { name: '📣 Anti Everyone', value: s(cfg.antieveryone), inline: true },
        { name: '⚡ Punition', value: `\`${cfg.punition || 'kick'}\``, inline: true },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
