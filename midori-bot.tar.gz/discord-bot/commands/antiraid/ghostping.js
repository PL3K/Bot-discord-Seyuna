const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'ghostping',
  description: 'Activer/configurer la détection de ghost ping',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const sub = args[0]?.toLowerCase();
    if (sub === 'off') {
      upsertConfig(message.guild.id, { ghostping_channel: null });
      return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('👻 Ghost Ping: **DÉSACTIVÉ**').setFooter({ text: '緑 • Midori 🌿' })] });
    }
    const ch = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
    if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+ghostping on <#salon>` ou `+ghostping off`')] });
    upsertConfig(message.guild.id, { ghostping_channel: ch.id });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`👻 Ghost Ping: **ACTIVÉ** — Logs dans ${ch}`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
