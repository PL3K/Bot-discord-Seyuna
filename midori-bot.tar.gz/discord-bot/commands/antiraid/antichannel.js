const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'antichannel',
  description: 'Protection salons create/delete/update on/off',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const action = args[0]?.toLowerCase();
    const val = args[1]?.toLowerCase() === 'on' ? 1 : 0;
    const map = { create: 'antichannel_create', delete: 'antichannel_delete', update: 'antichannel_update' };
    if (!map[action]) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+antichannel create/delete/update on/off`')] });
    upsertConfig(message.guild.id, { [map[action]]: val });
    message.reply({ embeds: [new EmbedBuilder().setColor(val ? '#57F287' : '#ED4245').setDescription(`📝 Anti-Channel ${action}: **${val ? 'ACTIVÉ' : 'DÉSACTIVÉ'}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
