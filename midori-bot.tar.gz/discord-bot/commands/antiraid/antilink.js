const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'antilink',
  description: 'Protection liens: invite / all / off',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const val = args[0]?.toLowerCase();
    if (!['invite', 'all', 'off'].includes(val)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+antilink invite/all/off`')] });
    upsertConfig(message.guild.id, { antilink: val });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`🔗 Anti-Link: **${val.toUpperCase()}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
