const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'antiban',
  description: 'Protection ban on/off',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const val = args[0]?.toLowerCase() === 'on' ? 1 : 0;
    upsertConfig(message.guild.id, { antiban: val });
    message.reply({ embeds: [new EmbedBuilder().setColor(val ? '#57F287' : '#ED4245').setDescription(`🔨 Anti-Ban: **${val ? 'ACTIVÉ' : 'DÉSACTIVÉ'}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
