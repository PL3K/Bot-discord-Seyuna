const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'server',
  description: 'Verrouiller/déverrouiller le serveur',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const sub = args[0]?.toLowerCase();
    if (sub === 'lock') {
      const channels = message.guild.channels.cache.filter(c => c.type === 0);
      for (const [, ch] of channels) {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: false, AddReactions: false }).catch(() => {});
      }
      upsertConfig(message.guild.id, { server_locked: 1 });
      message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('🔒 Serveur Verrouillé').setDescription('Le serveur a été verrouillé. Personne ne peut parler.').setFooter({ text: '緑 • Midori 🌿' })] });
    } else if (sub === 'unlock') {
      const channels = message.guild.channels.cache.filter(c => c.type === 0);
      for (const [, ch] of channels) {
        await ch.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: null, AddReactions: null }).catch(() => {});
      }
      upsertConfig(message.guild.id, { server_locked: 0 });
      message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🔓 Serveur Déverrouillé').setDescription('Le serveur a été déverrouillé.').setFooter({ text: '緑 • Midori 🌿' })] });
    } else {
      message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+server lock` ou `+server unlock`')] });
    }
  },
};
