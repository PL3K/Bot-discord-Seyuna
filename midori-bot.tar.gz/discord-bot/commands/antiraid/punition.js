const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'punition',
  description: 'Définir la punition antiraid (kick/ban/mute)',
  async execute(message, args, client) {
    if (!message.member.permissions.has('Administrator')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const val = args[0]?.toLowerCase();
    if (!['kick', 'ban', 'mute'].includes(val)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+punition kick/ban/mute`')] });
    upsertConfig(message.guild.id, { punition: val });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`⚡ Punition antiraid: **${val.toUpperCase()}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
