const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { giveaways, getConfig } = require('../../systems/database');

function parseTime(str) {
  const match = str.match(/^(\d+)(s|m|h|d)$/);
  if (!match) return null;
  const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[match[2]];
  return parseInt(match[1]) * mult;
}

module.exports = {
  name: 'giveaway',
  description: 'Lancer un Giveaway',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });

    if (!args[0]) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+giveaway <durée> <gagnants> <prix>`\nExemple: `+giveaway 1h 1 Nitro`')] });

    const duration = parseTime(args[0]);
    if (!duration) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Durée invalide. Exemples: `30s`, `5m`, `1h`, `1d`')] });

    const winners = parseInt(args[1]);
    if (isNaN(winners) || winners < 1) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Nombre de gagnants invalide.')] });

    const prize = args.slice(2).join(' ');
    if (!prize) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Veuillez indiquer un prix.')] });

    const endsAt = Date.now() + duration;
    const id = giveaways.create.run(message.channel.id, message.guild.id, message.author.id, prize, winners, endsAt).lastInsertRowid;

    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle(`🎊 GIVEAWAY — ${prize}`)
      .setDescription(`Réagissez avec 🎉 pour participer!\n\n👥 **Gagnants:** ${winners}\n⏰ **Fin:** <t:${Math.floor(endsAt / 1000)}:R>\n🎁 **Prix:** ${prize}\n👤 **Organisateur:** ${message.author}`)
      .setFooter({ text: `ID: ${id} • 緑 • Midori 🌿` })
      .setTimestamp(endsAt);

    const sent = await message.channel.send({ embeds: [embed] });
    await sent.react('🎉');
    giveaways.setMsg.run(sent.id, id);

    setTimeout(() => {
      require('../../systems/giveaway').endGiveaway(client, giveaways.getById.get(id));
    }, duration);

    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Giveaway **${prize}** lancé! [Voir](<${sent.url}>)`)] });

    const cfg = getConfig(message.guild.id);
    if (cfg.giveaway_log) {
      const logCh = message.guild.channels.cache.get(cfg.giveaway_log);
      if (logCh) logCh.send({ embeds: [new EmbedBuilder().setColor('#F1C40F').setDescription(`🎊 Giveaway **${prize}** lancé par ${message.author} dans ${message.channel}.`)] });
    }
  },
};
