const { EmbedBuilder } = require('discord.js');
const { giveaways } = require('../../systems/database');

module.exports = {
  name: 'reroll',
  description: 'Reroll un Giveaway',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const id = parseInt(args[0]);
    if (isNaN(id)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+reroll <ID>`')] });
    const ga = giveaways.getById.get(id);
    if (!ga || ga.guild_id !== message.guild.id || !ga.ended) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Giveaway introuvable ou pas encore terminé.')] });

    const ch = await client.channels.fetch(ga.channel_id).catch(() => null);
    if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Salon introuvable.')] });
    const msg = await ch.messages.fetch(ga.message_id).catch(() => null);
    if (!msg) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Message du giveaway introuvable.')] });

    const reaction = msg.reactions.cache.get('🎉');
    if (!reaction) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Aucune réaction trouvée.')] });

    const users = await reaction.users.fetch();
    const eligible = users.filter(u => !u.bot);
    if (!eligible.size) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Aucun participant valide.')] });

    const arr = [...eligible.values()];
    const winners = [];
    for (let i = 0; i < Math.min(ga.winners_count, arr.length); i++) {
      const idx = Math.floor(Math.random() * arr.length);
      winners.push(arr.splice(idx, 1)[0]);
    }

    ch.send({ embeds: [new EmbedBuilder().setColor('#F1C40F').setTitle('🎊 Reroll — Nouveaux Gagnants!').setDescription(`🏆 ${winners.map(w => w.toString()).join(', ')} remporte(nt) **${ga.prize}**!`).setFooter({ text: '緑 • Midori 🌿' })] });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Reroll effectué!`)] });
  },
};
