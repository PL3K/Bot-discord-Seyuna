const { EmbedBuilder } = require('discord.js');
const { giveaways } = require('../../systems/database');

module.exports = {
  name: 'end',
  description: 'Terminer un Giveaway',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const id = parseInt(args[0]);
    if (isNaN(id)) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Usage: `+end <ID>`')] });
    const ga = giveaways.getById.get(id);
    if (!ga || ga.guild_id !== message.guild.id) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Giveaway introuvable.')] });
    if (ga.ended) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Ce giveaway est déjà terminé.')] });
    require('../../systems/giveaway').endGiveaway(client, ga);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Giveaway \`#${id}\` terminé.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
