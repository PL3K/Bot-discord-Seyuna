const { EmbedBuilder } = require('discord.js');

const SIZE = 8;
const SNAKE = '🟩', FOOD = '🍎', EMPTY = '⬛';

module.exports = {
  name: 'snake',
  description: 'Jeu du serpent',
  async execute(message, args, client) {
    let snake = [{ x: 4, y: 4 }];
    let dir = { x: 1, y: 0 };
    let food = { x: Math.floor(Math.random() * SIZE), y: Math.floor(Math.random() * SIZE) };
    let score = 0;

    const render = () => {
      const grid = Array.from({ length: SIZE }, () => Array(SIZE).fill(EMPTY));
      snake.forEach(s => { if (s.x >= 0 && s.x < SIZE && s.y >= 0 && s.y < SIZE) grid[s.y][s.x] = SNAKE; });
      grid[food.y][food.x] = FOOD;
      return grid.map(r => r.join('')).join('\n');
    };

    const embed = () => new EmbedBuilder().setColor('#57F287').setTitle(`🐍 Snake — Score: ${score}`).setDescription(`${render()}\n\nContrôles: ⬆️⬇️⬅️➡️ (répondez u/d/l/r)`).setFooter({ text: '緑 • Midori 🌿' });
    const msg = await message.reply({ embeds: [embed()] });

    const filter = (m) => m.author.id === message.author.id && ['u','d','l','r'].includes(m.content.toLowerCase());
    const collector = message.channel.createMessageCollector({ filter, time: 60000 });

    collector.on('collect', async (m) => {
      m.delete().catch(() => {});
      const mv = { u: {x:0,y:-1}, d: {x:0,y:1}, l: {x:-1,y:0}, r: {x:1,y:0} }[m.content.toLowerCase()];
      dir = mv;
      const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

      if (head.x < 0 || head.x >= SIZE || head.y < 0 || head.y >= SIZE || snake.some(s => s.x === head.x && s.y === head.y)) {
        collector.stop();
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle(`💀 Game Over — Score: ${score}`).setDescription(render()).setFooter({ text: '緑 • Midori 🌿' })] });
      }

      snake.unshift(head);
      if (head.x === food.x && head.y === food.y) {
        score++;
        food = { x: Math.floor(Math.random() * SIZE), y: Math.floor(Math.random() * SIZE) };
      } else { snake.pop(); }

      await msg.edit({ embeds: [embed()] });
    });
  },
};
