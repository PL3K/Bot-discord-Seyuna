const { EmbedBuilder } = require('discord.js');

const EMPTY = '⚫', P1 = '🔴', P2 = '🟡';
const COLS = 7, ROWS = 6;

function createBoard() { return Array.from({ length: ROWS }, () => Array(COLS).fill(EMPTY)); }

function dropPiece(board, col, piece) {
  for (let r = ROWS - 1; r >= 0; r--) {
    if (board[r][col] === EMPTY) { board[r][col] = piece; return r; }
  }
  return -1;
}

function checkWin(board, piece) {
  for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS - 3; c++) if ([0,1,2,3].every(i => board[r][c+i] === piece)) return true;
  for (let r = 0; r < ROWS - 3; r++) for (let c = 0; c < COLS; c++) if ([0,1,2,3].every(i => board[r+i][c] === piece)) return true;
  for (let r = 0; r < ROWS - 3; r++) for (let c = 0; c < COLS - 3; c++) if ([0,1,2,3].every(i => board[r+i][c+i] === piece)) return true;
  for (let r = 3; r < ROWS; r++) for (let c = 0; c < COLS - 3; c++) if ([0,1,2,3].every(i => board[r-i][c+i] === piece)) return true;
  return false;
}

const nums = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣'];

module.exports = {
  name: 'puissance4',
  aliases: ['p4', 'connect4'],
  description: 'Jeu Puissance 4',
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    if (!target || target.user.bot || target.id === message.author.id) return message.reply('❌ Mentionnez un adversaire valide!');

    const board = createBoard();
    let currentPlayer = message.author;
    let currentPiece = P1;
    const players = { [message.author.id]: P1, [target.id]: P2 };

    const renderBoard = () => board.map(row => row.join('')).join('\n') + '\n' + nums.join('');
    const embed = () => new EmbedBuilder().setColor('#5865F2').setTitle('🔴🟡 Puissance 4').setDescription(`${renderBoard()}\n\n${currentPiece} Tour de **${currentPlayer.username}** — Tapez 1-7`).setFooter({ text: '緑 • Midori 🌿' });

    const msg = await message.reply({ embeds: [embed()] });
    const filter = (m) => [message.author.id, target.id].includes(m.author.id) && /^[1-7]$/.test(m.content);
    const collector = message.channel.createMessageCollector({ filter, time: 120000 });

    collector.on('collect', async (m) => {
      if (m.author.id !== currentPlayer.id) return;
      m.delete().catch(() => {});
      const col = parseInt(m.content) - 1;
      const row = dropPiece(board, col, currentPiece);
      if (row === -1) return;

      if (checkWin(board, currentPiece)) {
        collector.stop();
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🏆 Puissance 4 — Victoire!').setDescription(`${renderBoard()}\n\n${currentPiece} **${currentPlayer.username}** a gagné!`).setFooter({ text: '緑 • Midori 🌿' })] });
      }

      currentPlayer = currentPlayer.id === message.author.id ? target.user : message.author;
      currentPiece = currentPiece === P1 ? P2 : P1;
      await msg.edit({ embeds: [embed()] });
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') msg.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('⏰ Temps écoulé!')] }).catch(() => {});
    });
  },
};
