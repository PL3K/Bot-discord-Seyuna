module.exports = {
  name: 'ascii',
  description: 'Écrire en ASCII',
  async execute(message, args, client) {
    const text = args.join(' ');
    if (!text) return message.reply('❌ Usage: `+ascii <texte>`');
    const map = { a:'/-\\', b:'|3', c:'(', d:'|)', e:'3', f:'|=', g:'6', h:'|-|', i:'|', j:']', k:'|<', l:'|_', m:'|v|', n:'|\\|', o:'0', p:'|D', q:'(_,)', r:'|2', s:'$', t:'+', u:'|_|', v:'\\/', w:'\\/\\/', x:'><', y:'`/', z:'2' };
    const result = text.toLowerCase().split('').map(c => map[c] || c.toUpperCase()).join(' ');
    message.reply(`\`\`\`${result}\`\`\``);
  },
};
