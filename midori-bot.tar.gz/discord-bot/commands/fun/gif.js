const { EmbedBuilder } = require('discord.js');

const gifs = {
  happy: ['https://media.giphy.com/media/JltOMwYmi0VrO/giphy.gif'],
  dance: ['https://media.giphy.com/media/l0MYGb1LuZ3n7dRnO/giphy.gif'],
  cat: ['https://media.giphy.com/media/JIX9t2j0ZTN9S/giphy.gif'],
  dog: ['https://media.giphy.com/media/4Zo41lhzKt6iZ8xff9/giphy.gif'],
};

module.exports = {
  name: 'gif',
  description: 'Rechercher un GIF',
  async execute(message, args, client) {
    const query = args.join(' ') || 'random';
    const options = Object.values(gifs).flat();
    const url = options[Math.floor(Math.random() * options.length)];
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`🎞️ GIF — ${query}`)
      .setImage(url)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
