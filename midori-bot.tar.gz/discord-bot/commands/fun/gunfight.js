const { EmbedBuilder } = require('discord.js');

const activeGunfights = new Map();

module.exports = {
  name: 'gunfight',
  description: 'Duel au pistolet',
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mentionnez un adversaire!');
    if (target.id === message.author.id) return message.reply('❌ Vous ne pouvez pas vous défier vous-même!');
    if (target.user.bot) return message.reply('❌ Les bots ne peuvent pas jouer!');

    const key = `${message.guild.id}-${message.channel.id}`;
    if (activeGunfights.has(key)) return message.reply('❌ Un duel est déjà en cours dans ce salon!');

    const word = ['TIRE', 'SHOOT', 'FEU', 'BANG', 'PAN'][Math.floor(Math.random() * 5)];
    const delay = Math.floor(Math.random() * 4000) + 2000;

    activeGunfights.set(key, { challenger: message.author.id, challenged: target.id, word });

    await message.reply({ embeds: [new EmbedBuilder().setColor('#FEE75C').setDescription(`🔫 **${message.author.username}** défie **${target.user.username}** en duel!\n\nPréparez-vous... Tapez le mot **"${word}"** en premier pour gagner!\n⏳ Le duel commence dans ${delay / 1000} secondes!`)] });

    setTimeout(async () => {
      if (!activeGunfights.has(key)) return;
      await message.channel.send(`**🔫 ${word}!**`);

      const filter = (m) => [message.author.id, target.id].includes(m.author.id) && m.content.toUpperCase() === word;
      const collector = message.channel.createMessageCollector({ filter, time: 5000, max: 1 });

      collector.on('collect', (m) => {
        activeGunfights.delete(key);
        message.channel.send({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🏆 Duel terminé!').setDescription(`**${m.author.username}** a gagné le duel! 🔫💨`).setFooter({ text: '緑 • Midori 🌿' })] });
      });

      collector.on('end', (collected) => {
        activeGunfights.delete(key);
        if (!collected.size) {
          message.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('💀 Personne n\'a répondu à temps. Les deux perdent!')] });
        }
      });
    }, delay);
  },
};
