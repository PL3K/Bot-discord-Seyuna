const { EmbedBuilder } = require('discord.js');

const words = ['discord', 'serveur', 'botmidori', 'musique', 'gaming', 'anime', 'france', 'moderateur', 'seyuna', 'giveaway', 'ticket', 'bannir'];

module.exports = {
  name: 'mot',
  description: 'Jeu du pendu',
  async execute(message, args, client) {
    const word = words[Math.floor(Math.random() * words.length)];
    let guessed = [];
    let errors = 0;
    const maxErrors = 6;
    const pendu = ['😮', '😟', '😰', '😨', '😱', '💀', '☠️'];

    const display = () => word.split('').map(l => guessed.includes(l) ? `**${l}**` : '\\_').join(' ');
    const embed = () => new EmbedBuilder().setColor('#5865F2').setTitle('🎮 Jeu du Pendu').setDescription(`Mot: ${display()}\n\nErreurs: ${errors}/${maxErrors} ${pendu[errors]}\nLettres essayées: ${guessed.join(', ') || 'Aucune'}`).setFooter({ text: 'Tapez une lettre! • 緑 • Midori 🌿' });
    const msg = await message.reply({ embeds: [embed()] });

    const filter = (m) => m.author.id === message.author.id && m.content.length === 1 && /[a-z]/i.test(m.content);
    const collector = message.channel.createMessageCollector({ filter, time: 60000 });

    collector.on('collect', async (m) => {
      m.delete().catch(() => {});
      const letter = m.content.toLowerCase();
      if (guessed.includes(letter)) return;
      guessed.push(letter);
      if (!word.includes(letter)) errors++;

      const won = word.split('').every(l => guessed.includes(l));
      if (won) {
        collector.stop();
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🏆 Gagné!').setDescription(`${m.author} a trouvé le mot **${word}**!`).setFooter({ text: '緑 • Midori 🌿' })] });
      }
      if (errors >= maxErrors) {
        collector.stop();
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('☠️ Perdu!').setDescription(`Le mot était **${word}**. Dommage!`).setFooter({ text: '緑 • Midori 🌿' })] });
      }
      await msg.edit({ embeds: [embed()] });
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') msg.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`⏰ Temps écoulé! Le mot était **${word}**.`)] }).catch(() => {});
    });
  },
};
