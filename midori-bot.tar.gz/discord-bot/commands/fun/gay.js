const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'gay',
  description: 'Combien de % gay êtes vous?',
  async execute(message, args, client) {
    const target = message.mentions.users.first() || message.author;
    const pct = Math.floor(Math.random() * 101);
    const bar = '🏳️‍🌈'.repeat(Math.floor(pct / 10)) + '▬'.repeat(10 - Math.floor(pct / 10));
    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('🏳️‍🌈 Gay-O-Mètre')
      .setDescription(`${target.username} est gay à **${pct}%**!\n${bar}`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
