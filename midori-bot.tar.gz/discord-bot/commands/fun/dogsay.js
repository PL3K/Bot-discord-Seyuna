const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'dogsay',
  description: 'Un chien qui parle',
  async execute(message, args, client) {
    const text = args.join(' ');
    if (!text) return message.reply('❌ Usage: `+dogsay <texte>`');
    const embed = new EmbedBuilder()
      .setColor('#D4A76A')
      .setDescription(`🐶 **${text}** \`*wouf*\``)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
