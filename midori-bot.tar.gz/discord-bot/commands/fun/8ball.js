const { EmbedBuilder } = require('discord.js');

const reponses = [
  '✅ Oui, absolument!', '✅ C\'est certain.', '✅ Sans aucun doute.',
  '✅ Tu peux y compter.', '✅ C\'est bien ainsi.', '✅ Très probablement.',
  '⚠️ Difficile à dire.', '⚠️ Réessaie plus tard.', '⚠️ Je préfère ne pas répondre.',
  '⚠️ Je ne peux pas prédire.', '❌ Ne compte pas là-dessus.', '❌ Ma réponse est non.',
  '❌ Mes sources disent non.', '❌ Les perspectives ne sont pas bonnes.', '❌ Très improbable.',
];

module.exports = {
  name: '8ball',
  description: 'Poser une question au bot',
  async execute(message, args, client) {
    const question = args.join(' ');
    if (!question) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Posez une question!')] });
    const rep = reponses[Math.floor(Math.random() * reponses.length)];
    const embed = new EmbedBuilder()
      .setColor('#9B59B6')
      .setTitle('🎱 Magic 8-Ball')
      .addFields(
        { name: '❓ Question', value: question, inline: false },
        { name: '💬 Réponse', value: rep, inline: false },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
