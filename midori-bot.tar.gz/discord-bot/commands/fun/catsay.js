const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'catsay',
  description: 'Un chat qui parle',
  async execute(message, args, client) {
    const text = args.join(' ');
    if (!text) return message.reply('❌ Usage: `+catsay <texte>`');
    const embed = new EmbedBuilder()
      .setColor('#F8A5C2')
      .setDescription(`🐱 **${text}** \`*miaou*\``)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
