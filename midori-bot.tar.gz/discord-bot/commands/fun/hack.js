const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'hack',
  description: 'Faux hack d\'un utilisateur',
  async execute(message, args, client) {
    const target = message.mentions.users.first() || (args[0] ? await client.users.fetch(args[0]).catch(() => null) : null);
    if (!target) return message.reply('❌ Mentionnez un utilisateur.');
    const steps = [
      `🔍 Localisation de **${target.username}**...`,
      `📡 Connexion au serveur distant...`,
      `🔑 Tentative de déchiffrement du mot de passe...`,
      `💾 Extraction des données personnelles...`,
      `🌐 IP trouvée: \`192.168.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}\``,
      `📧 Email: \`${target.username.toLowerCase().replace(/\s/g,'_')}@gmail.com\``,
      `🔐 Mot de passe: \`${'*'.repeat(Math.floor(Math.random()*8+6))}\``,
      `✅ **Hack réussi!** (C'est une blague bien sûr 😄)`,
    ];
    let i = 0;
    const msg = await message.reply(`⏳ Démarrage du hack...`);
    const interval = setInterval(async () => {
      if (i >= steps.length) { clearInterval(interval); return; }
      await msg.edit(steps[i]).catch(() => clearInterval(interval));
      i++;
    }, 1500);
  },
};
