const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'insta',
  description: 'Fausse recherche Instagram',
  async execute(message, args, client) {
    const query = args.join(' ');
    if (!query) return message.reply('❌ Usage: `+insta <nom>`');
    const followers = Math.floor(Math.random() * 100000);
    const posts = Math.floor(Math.random() * 500);
    const following = Math.floor(Math.random() * 1000);
    const embed = new EmbedBuilder()
      .setColor('#E1306C')
      .setTitle(`📸 Instagram — @${query.replace(/\s/g, '_')}`)
      .addFields(
        { name: '👥 Abonnés', value: `${followers.toLocaleString()}`, inline: true },
        { name: '📤 Abonnements', value: `${following.toLocaleString()}`, inline: true },
        { name: '📸 Publications', value: `${posts}`, inline: true },
      )
      .setDescription(`[Voir le profil](https://instagram.com/${query.replace(/\s/g, '_')})`)
      .setFooter({ text: '緑 • Midori 🌿 — Résultat fictif' });
    message.reply({ embeds: [embed] });
  },
};
