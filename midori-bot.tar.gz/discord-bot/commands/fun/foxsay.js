const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'foxsay',
  description: 'Un renard qui parle',
  async execute(message, args, client) {
    const text = args.join(' ');
    if (!text) return message.reply('❌ Usage: `+foxsay <texte>`');
    const embed = new EmbedBuilder()
      .setColor('#E67E22')
      .setDescription(`🦊 **${text}** \`*yip*\``)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
