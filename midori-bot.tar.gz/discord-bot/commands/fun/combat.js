const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'combat',
  description: 'Combattre un membre',
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mentionnez un adversaire!');
    if (target.id === message.author.id) return message.reply('❌ Vous ne pouvez pas vous battre vous-même!');

    const attacker = message.member;
    const atpv = Math.floor(Math.random() * 100) + 1;
    const dfpv = Math.floor(Math.random() * 100) + 1;
    const winner = atpv > dfpv ? attacker : target;
    const loser = atpv > dfpv ? target : attacker;

    const bar = (pv) => '█'.repeat(Math.ceil(pv / 10)) + '░'.repeat(10 - Math.ceil(pv / 10));

    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('⚔️ Combat!')
      .setDescription(`**${attacker.user.username}** vs **${target.user.username}**`)
      .addFields(
        { name: `${attacker.user.username}`, value: `${bar(atpv)} ${atpv} PV`, inline: true },
        { name: `${target.user.username}`, value: `${bar(dfpv)} ${dfpv} PV`, inline: true },
        { name: '🏆 Vainqueur', value: `**${winner.user.username}** remporte le combat!`, inline: false },
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
