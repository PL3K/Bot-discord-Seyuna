const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'click',
  description: 'Jeu de rapidité',
  async execute(message, args, client) {
    const embed = new EmbedBuilder().setColor('#FEE75C').setDescription('⏳ Préparez-vous...');
    const msg = await message.reply({ embeds: [embed] });
    const delay = Math.floor(Math.random() * 4000) + 2000;

    setTimeout(async () => {
      const start = Date.now();
      await msg.edit({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('**🖱️ CLIQUEZ! Répondez "go" maintenant!**')] });

      const filter = (m) => m.author.id !== client.user.id && m.content.toLowerCase() === 'go';
      const collector = message.channel.createMessageCollector({ filter, time: 5000, max: 1 });

      collector.on('collect', (m) => {
        const time = Date.now() - start;
        m.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('⚡ Résultat!').setDescription(`${m.author} a répondu en **${time}ms**!`).setFooter({ text: '緑 • Midori 🌿' })] });
      });

      collector.on('end', (collected) => {
        if (!collected.size) msg.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('💀 Personne n\'a cliqué à temps!')] });
      });
    }, delay);
  },
};
