const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'fessé',
  aliases: ['fesse', 'spank'],
  description: 'Donner une fessée',
  async execute(message, args, client) {
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mentionnez quelqu\'un à fesser!');
    const embed = new EmbedBuilder()
      .setColor('#E91E63')
      .setDescription(`👋 **${message.author.username}** a donné une belle fessée à **${target.user.username}**! 🍑`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
