const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');

module.exports = {
  name: 'antijoin',
  description: 'Empêcher de rejoindre les salons vocaux (sauf WL)',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const val = args[0]?.toLowerCase() === 'on' ? 1 : 0;
    upsertConfig(message.guild.id, { antijoin: val });
    message.reply({ embeds: [new EmbedBuilder().setColor(val ? '#57F287' : '#ED4245').setDescription(`🔊 Anti-Join vocal: **${val ? 'ACTIVÉ' : 'DÉSACTIVÉ'}**`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
