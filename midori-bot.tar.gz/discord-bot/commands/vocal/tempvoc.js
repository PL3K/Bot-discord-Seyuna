const { EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const { tempVocs } = require('../../systems/database');

module.exports = {
  name: 'tempvoc',
  description: 'Gérer votre salon vocal temporaire',
  async execute(message, args, client) {
    if (!message.member.voice?.channel) {
      return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous devez être dans un salon vocal.')] });
    }

    const existing = tempVocs.getByOwner.get(message.author.id, message.guild.id);

    if (!existing) {
      const cat = message.member.voice.channel.parentId;
      const ch = await message.guild.channels.create({
        name: `🔊 ${message.author.username}`,
        type: ChannelType.GuildVoice,
        parent: cat,
        userLimit: 10,
        permissionOverwrites: [
          { id: message.guild.roles.everyone, allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
          { id: message.author.id, allow: [PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers, PermissionFlagsBits.MoveMembers, PermissionFlagsBits.ManageChannels] },
        ],
      }).catch(() => null);

      if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Impossible de créer le vocal.')] });

      await message.member.voice.setChannel(ch).catch(() => {});
      tempVocs.add.run(ch.id, message.author.id, message.guild.id);

      return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setTitle('🔊 Vocal Temporaire Créé').setDescription(`Votre salon vocal temporaire **${ch.name}** a été créé!\nVous avez les droits de gestion.`).setFooter({ text: '緑 • Midori 🌿' })] });
    }

    const sub = args[0]?.toLowerCase();
    const ch = message.guild.channels.cache.get(existing.channel_id);

    if (sub === 'rename' && args[1]) {
      const newName = args.slice(1).join(' ');
      if (ch) await ch.setName(newName).catch(() => {});
      return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Vocal renommé en **${newName}**.`)] });
    }
    if (sub === 'limit' && args[1]) {
      if (ch) await ch.setUserLimit(parseInt(args[1])).catch(() => {});
      return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Limite réglée à **${args[1]}** membres.`)] });
    }
    if (sub === 'delete') {
      if (ch) await ch.delete().catch(() => {});
      tempVocs.delete.run(existing.channel_id);
      return message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription('✅ Vocal temporaire supprimé.')] });
    }

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🔊 Gestion — Vocal Temporaire')
      .setDescription(`Votre salon: ${ch ? ch.toString() : 'Salon supprimé'}\n\n**Commandes:**\n\`+tempvoc rename <nom>\` — Renommer\n\`+tempvoc limit <n>\` — Limite de membres\n\`+tempvoc delete\` — Supprimer`)
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
