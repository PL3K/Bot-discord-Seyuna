const { EmbedBuilder } = require('discord.js');
const { db } = require('../../systems/database');

module.exports = {
  name: 'blv',
  description: 'Bannir un utilisateur des salons vocaux (Blacklist Voice)',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    db.prepare('INSERT OR IGNORE INTO whitelist (user_id, guild_id, added_by) VALUES (?, ?, ?)').run(`blv_${target.id}`, message.guild.id, message.author.id);
    if (target.voice?.channel) await target.voice.disconnect().catch(() => {});
    message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`✅ ${target} blacklisté des salons vocaux.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
