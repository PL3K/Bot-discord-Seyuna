const { EmbedBuilder } = require('discord.js');
const { whitelist } = require('../../systems/database');

module.exports = {
  name: 'unvwl',
  description: 'Retirer la permission d\'accès aux vocaux',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    whitelist.remove.run(target.id, message.guild.id);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ ${target} retiré de la Voice Whitelist.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
