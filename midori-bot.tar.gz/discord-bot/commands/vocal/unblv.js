const { EmbedBuilder } = require('discord.js');
const { db } = require('../../systems/database');

module.exports = {
  name: 'unblv',
  description: 'Débannir un utilisateur des salons vocaux',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Membre introuvable.')] });
    db.prepare('DELETE FROM whitelist WHERE user_id = ? AND guild_id = ?').run(`blv_${target.id}`, message.guild.id);
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ ${target} retiré de la Blacklist Voice.`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
