const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'tempvocpanel',
  description: 'Panel de configuration des vocaux temporaires',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageChannels')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🔊 Panel — Vocaux Temporaires')
      .setDescription(
        '**Commandes disponibles:**\n\n' +
        '`+tempvoc` — Créer/gérer votre salon vocal temporaire\n' +
        '`+tempvoc rename <nom>` — Renommer votre salon\n' +
        '`+tempvoc limit <n>` — Régler la limite\n' +
        '`+tempvoc delete` — Supprimer votre salon\n' +
        '`+antijoin on/off` — Bloquer les rejoins vocaux\n' +
        '`+vwl @user` — Voice Whitelist\n' +
        '`+unvwl @user` — Retirer la Voice Whitelist\n' +
        '`+blv @user` — Blacklist Voice\n' +
        '`+unblv @user` — Retirer la Blacklist Voice'
      )
      .setFooter({ text: '緑 • Midori 🌿' });
    message.reply({ embeds: [embed] });
  },
};
