const { EmbedBuilder } = require('discord.js');
const { upsertConfig } = require('../../systems/database');
module.exports = {
  name: 'ticketlog',
  description: 'Configurer le salon de logs tickets',
  async execute(message, args, client) {
    if (!message.member.permissions.has('ManageGuild')) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Permission refusée.')] });
    const ch = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
    if (!ch) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Salon introuvable.')] });
    upsertConfig(message.guild.id, { ticket_log: ch.id });
    message.reply({ embeds: [new EmbedBuilder().setColor('#57F287').setDescription(`✅ Ticket log configuré: ${ch}`).setFooter({ text: '緑 • Midori 🌿' })] });
  },
};
