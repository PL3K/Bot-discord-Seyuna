const { EmbedBuilder } = require('discord.js');

const ACTIVITIES = {
  youtube: '880218394199220334',
  poker: '755827207812677713',
  chess: '832012774040141894',
  checkers: '832013003968348200',
  betrayal: '773336526917861400',
  fishington: '814288819477610496',
  lettertile: '879863686565621790',
  wordssnack: '879863976006127627',
  doodlecrew: '878067389634314250',
  spellcast: '852509694341283871',
  awkword: '879863881349087252',
  puttparty: '945737671921powerpoint',
  sketchheads: '902271654783242291',
  ocho: '832025144389533716',
};

module.exports = {
  name: 'activity',
  description: 'Lancer une activité dans votre salon vocal',
  async execute(message, args, client) {
    const member = message.member;
    if (!member.voice?.channel) return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Vous devez être dans un salon vocal.')] });

    const actName = args[0]?.toLowerCase() || 'youtube';
    const actId = ACTIVITIES[actName];

    if (!actId) {
      const list = Object.keys(ACTIVITIES).join(', ');
      return message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('🎮 Activités disponibles').setDescription(list).setFooter({ text: '緑 • Midori 🌿' })] });
    }

    try {
      const invite = await member.voice.channel.createInvite({
        targetType: 2,
        targetApplication: actId,
        maxAge: 86400,
      });
      message.reply({ embeds: [new EmbedBuilder().setColor('#5865F2').setTitle(`🎮 Activity — ${actName}`).setDescription(`[Cliquez ici pour rejoindre!](${invite.url})\n\n**Salon:** ${member.voice.channel.name}`).setFooter({ text: '緑 • Midori 🌿' })] });
    } catch (e) {
      message.reply({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('❌ Impossible de créer l\'activité. Vérifiez les permissions du bot.')] });
    }
  },
};
