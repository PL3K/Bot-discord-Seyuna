const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../systems/database');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    const cfg = getConfig(member.guild.id);
    if (cfg.leave_channel) {
      const ch = member.guild.channels.cache.get(cfg.leave_channel);
      if (ch) {
        const embed = new EmbedBuilder()
          .setColor('#ED4245')
          .setTitle(`Au revoir!`)
          .setDescription(`${member.user.tag} a quitté le serveur.`)
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
          .setTimestamp();
        ch.send({ embeds: [embed] }).catch(() => {});
      }
    }
  },
};
