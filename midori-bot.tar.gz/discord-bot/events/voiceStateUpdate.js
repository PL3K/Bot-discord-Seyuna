const { PermissionFlagsBits, ChannelType } = require('discord.js');
const { getConfig, tempVocs } = require('../systems/database');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState, client) {
    const guild = newState.guild || oldState.guild;
    const cfg = getConfig(guild.id);

    // Nettoyage des vocaux temporaires vides
    if (oldState.channel) {
      const tv = tempVocs.get.get(oldState.channel.id);
      if (tv && oldState.channel.members.size === 0) {
        oldState.channel.delete().catch(() => {});
        tempVocs.delete.run(oldState.channel.id);
      }
    }
  },
};
