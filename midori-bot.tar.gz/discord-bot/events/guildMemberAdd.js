const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../systems/database');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const cfg = getConfig(member.guild.id);
    if (cfg.auto_role) {
      const role = member.guild.roles.cache.get(cfg.auto_role);
      if (role) member.roles.add(role).catch(() => {});
    }
    if (cfg.welcome_channel) {
      const ch = member.guild.channels.cache.get(cfg.welcome_channel);
      if (ch) {
        const embed = new EmbedBuilder()
          .setColor('#57F287')
          .setTitle(`Bienvenue sur ${member.guild.name}!`)
          .setDescription(`${member} vient de rejoindre le serveur!\n**Membre:** #${member.guild.memberCount}`)
          .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
          .setTimestamp();
        ch.send({ embeds: [embed] }).catch(() => {});
      }
    }
  },
};
