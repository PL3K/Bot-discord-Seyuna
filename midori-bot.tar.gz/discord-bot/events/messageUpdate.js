const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../systems/database');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMsg, newMsg, client) {
    if (!newMsg.guild || newMsg.author?.bot) return;
    if (oldMsg.content === newMsg.content) return;
    const cfg = getConfig(newMsg.guild.id);
    if (!cfg.message_log) return;
    const logCh = newMsg.guild.channels.cache.get(cfg.message_log);
    if (!logCh) return;
    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('✏️ Message Modifié')
      .setDescription(`**Auteur:** ${newMsg.author}\n**Salon:** ${newMsg.channel}\n**Avant:** ${oldMsg.content?.slice(0, 512) || '*Vide*'}\n**Après:** ${newMsg.content?.slice(0, 512) || '*Vide*'}`)
      .setTimestamp();
    logCh.send({ embeds: [embed] }).catch(() => {});
  },
};
