const { EmbedBuilder } = require('discord.js');
const { getConfig, snipe } = require('../systems/database');

module.exports = {
  name: 'messageDelete',
  async execute(message, client) {
    if (!message.guild || message.author?.bot) return;

    // Snipe
    if (message.content) {
      snipe.set.run(message.guild.id, message.channel.id, message.author?.id || '0', message.content);
    }

    // Message log
    const cfg = getConfig(message.guild.id);
    if (!cfg.message_log) return;
    const logCh = message.guild.channels.cache.get(cfg.message_log);
    if (!logCh) return;

    const embed = new EmbedBuilder()
      .setColor('#ED4245')
      .setTitle('🗑️ Message Supprimé')
      .setDescription(`**Auteur:** ${message.author || 'Inconnu'}\n**Salon:** ${message.channel}\n**Contenu:** ${message.content?.slice(0, 1024) || '*Vide*'}`)
      .setTimestamp();
    logCh.send({ embeds: [embed] }).catch(() => {});
  },
};
