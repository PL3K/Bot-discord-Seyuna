const { EmbedBuilder } = require('discord.js');
const { getConfig } = require('../systems/database');
const config = require('../config/config');

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const guildConfig = getConfig(message.guild.id);
    const prefix = guildConfig.prefix || config.prefix;

    // Anti-ghost ping
    if (guildConfig.ghostping_channel) {
      if (message.mentions.users.size > 0 || message.mentions.roles.size > 0) {
        client.once('messageDelete', async (deleted) => {
          if (deleted.id !== message.id) return;
          const ch = message.guild.channels.cache.get(guildConfig.ghostping_channel);
          if (!ch) return;
          const embed = new EmbedBuilder()
            .setColor('#FF6B6B')
            .setTitle('👻 Ghost Ping Détecté')
            .setDescription(`**Auteur:** ${message.author} (\`${message.author.id}\`)\n**Salon:** ${message.channel}\n**Mentions:** ${message.mentions.users.map(u => u.toString()).join(', ')}`)
            .setTimestamp();
          ch.send({ embeds: [embed] });
        });
      }
    }

    // Anti-link
    if (guildConfig.antilink && guildConfig.antilink !== 'off') {
      const inviteReg = /discord\.gg\/[a-zA-Z0-9]+/;
      const linkReg = /https?:\/\/[^\s]+/;
      const isInvite = inviteReg.test(message.content);
      const isLink = linkReg.test(message.content);
      const isWl = require('../systems/database').whitelist.check.get(message.author.id, message.guild.id);
      const isAdmin = message.member.permissions.has('Administrator');
      if ((guildConfig.antilink === 'invite' && isInvite || guildConfig.antilink === 'all' && isLink) && !isWl && !isAdmin) {
        message.delete().catch(() => {});
        return message.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`❌ ${message.author}, les liens ne sont pas autorisés ici.`)] }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }
    }

    // Anti-everyone
    if (guildConfig.antieveryone && message.content.includes('@everyone') || message.content.includes('@here')) {
      const isWl = require('../systems/database').whitelist.check.get(message.author.id, message.guild.id);
      const isAdmin = message.member.permissions.has('Administrator');
      if (!isWl && !isAdmin && !message.member.permissions.has('MentionEveryone')) {
        message.delete().catch(() => {});
        return message.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(`❌ ${message.author}, les mentions @everyone/@here sont interdites.`)] }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
      }
    }

    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    if (!commandName) return;

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
      await command.execute(message, args, client);
    } catch (err) {
      console.error(`[CMD:${commandName}]`, err.message);
      const embed = new EmbedBuilder()
        .setColor('#ED4245')
        .setDescription(`❌ Une erreur est survenue lors de l'exécution de cette commande.`);
      message.channel.send({ embeds: [embed] }).catch(() => {});
    }
  },
};
