const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { getConfig, db } = require('../systems/database');
const config = require('../config/config');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    // ── Select Menu Help ─────────────────────────────────
    if (interaction.isStringSelectMenu() && interaction.customId === 'help_category') {
      const category = interaction.values[0];
      const embed = getHelpEmbed(category, interaction.guild, client);
      await interaction.update({ embeds: [embed] }).catch(() => {});
      return;
    }

    // ── Button rôle ──────────────────────────────────────
    if (interaction.isButton() && interaction.customId.startsWith('buttonrole_')) {
      const roleId = interaction.customId.replace('buttonrole_', '');
      const member = interaction.member;
      if (!member) return;
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(roleId).catch(() => {});
        await interaction.reply({ content: `✅ Rôle <@&${roleId}> retiré.`, ephemeral: true });
      } else {
        await member.roles.add(roleId).catch(() => {});
        await interaction.reply({ content: `✅ Rôle <@&${roleId}> ajouté.`, ephemeral: true });
      }
      return;
    }

    // ── Ticket close ─────────────────────────────────────
    if (interaction.isButton() && interaction.customId === 'ticket_close') {
      const { tickets } = require('../systems/database');
      const ticket = tickets.getByChannel.get(interaction.channel.id, 'open');
      if (!ticket) return interaction.reply({ content: '❌ Ce ticket est déjà fermé.', ephemeral: true });
      tickets.close.run('closed', interaction.channel.id);
      await interaction.channel.send({ embeds: [new EmbedBuilder().setColor('#ED4245').setDescription('🔒 Ticket fermé. Le salon sera supprimé dans 5 secondes...')] });
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
      return;
    }
  },
};

function getHelpEmbed(category, guild, client) {
  const cfg = getConfig(guild.id);
  const prefix = cfg.prefix || '+';
  const color = '#2b2d31';

  const categories = {
    home: {
      title: '⛩️ Accueil — Midori 🌿',
      desc: `Bienvenue sur **Midori 🌿 • みどり**\nCe bot appartient à votre serveur.\n\n🔍 Choisissez une catégorie pour voir les commandes.\n\n緑 • Préfixe actuel : **${prefix}**`,
    },
    premium: {
      title: '💎 Commandes Premium',
      desc: `\`${prefix}backup\` — Créer et charger des sauvegardes du serveur\n\`${prefix}ticket\` — Panel de tickets configurable ultra complet\n\`${prefix}voicetext\` — Salons textuels temporaires liés aux vocaux\n\`${prefix}massrole\` — Attribuer ou retirer des rôles massivement\n\`${prefix}clear all\` — Supprimer tous les salons du serveur (Owner)\n\`${prefix}wl\` — Accès à la whitelist illimitée`,
    },
    antiraid: {
      title: '⚔️ Configuration de l\'Antiraid',
      desc: `\`${prefix}secur\` — Configurer les protections de l'antiraid\n\`${prefix}secur on\` — Active toutes les protections\n\`${prefix}secur off\` — Désactive toutes les protections\n\`${prefix}punition\` — Choisir la punition antiraid\n\`${prefix}antiadmin on/off\` — Protection admin\n\`${prefix}antiban on/off\` — Protection ban\n\`${prefix}antiupdate on/off\` — Protection maj\n\`${prefix}antibot on/off\` — Protection bots\n\`${prefix}antidown on/off\` — Protection suppression\n\`${prefix}antilink invite/all/off\` — Protection liens\n\`${prefix}antieveryone on/off\` — Protection @everyone\n\`${prefix}antichannel create/delete/update on/off\`\n\`${prefix}antirole create/delete/update on/off\`\n\`${prefix}antiwebhook on/off\`\n\`${prefix}server lock/unlock\`\n\`${prefix}ghostping on <#salon> / off\``,
    },
    gestionperm: {
      title: '📚 Gestion Permission',
      desc: `\`${prefix}perm\` — Afficher les permissions d'un membre\n\`${prefix}gestion\` — Modules de gestion\n\`${prefix}pall\` — Désactive toutes les permissions\n\`${prefix}padmin\` — Désactive les permissions administrateur\n\`${prefix}prole\` — Désactive les permissions rôles\n\`${prefix}pban\` — Désactive les permissions ban\n\`${prefix}pkick\` — Désactive les permissions kick\n\`${prefix}pvoc\` — Désactive les permissions vocal\n\`${prefix}pwebhooks\` — Désactive les permissions webhooks\n\`${prefix}pviewc\` — Désactive les permissions voir les salons\n\`${prefix}pserveur\` — Désactive Gérer le serveur\n\`${prefix}peveryone\` — Désactive les permissions Everyone`,
    },
    utilitaire: {
      title: '🎮 Utilitaire — Commandes Public',
      desc: `\`${prefix}help\` — Panel d'aide\n\`${prefix}help msg\` — Variables messages\n\`${prefix}ping\` — Ping du bot\n\`${prefix}avatar [id/mention]\` — Avatar d'un membre\n\`${prefix}banner [id/mention]\` — Bannière d'un membre\n\`${prefix}serveur info\` — Informations du serveur\n\`${prefix}serveur pic\` — Photo du serveur\n\`${prefix}serveur banner\` — Bannière du serveur\n\`${prefix}roleinfo [role]\` — Infos sur un rôle\n\`${prefix}find [@/ID]\` — Chercher un membre en vocal\n\`${prefix}stats\` — Statistiques du bot\n\`${prefix}snipe\` — Dernier message supprimé\n\`${prefix}suggest\` — Faire une suggestion\n\`${prefix}userinfo\` — Infos utilisateur\n\`${prefix}bypass\` — Voir quel antiraid bypass quoi\n\`${prefix}vc\` — Stats vocaux/membres\n\`${prefix}vote\` — Voter pour le bot\n\`${prefix}invite\` — Inviter le bot\n\`${prefix}confess\` — Message anonyme`,
    },
    moderation: {
      title: '⚔️ Modération',
      desc: `\`${prefix}adminlist\` — Liste des admins\n\`${prefix}botlist\` — Liste des bots\n\`${prefix}rlist\` — Liste avec permission Gérer les rôles\n\`${prefix}mute\` — Rendre muet\n\`${prefix}unmute\` — Redonner la parole\n\`${prefix}emoji\` — Créer un emoji\n\`${prefix}hide\` — Cacher un salon\n\`${prefix}unhide\` — Rendre visible un salon\n\`${prefix}lock\` — Fermer un salon\n\`${prefix}unlock\` — Ouvrir un salon\n\`${prefix}lockall\` — Fermer tous les salons\n\`${prefix}unlockall\` — Ouvrir tous les salons\n\`${prefix}config\` — Configuration du bot\n\`${prefix}addrole\` — Ajouter un rôle\n\`${prefix}delrole\` — Retirer un rôle\n\`${prefix}annonce\` — Annonce admin\n\`${prefix}kick\` — Expulser\n\`${prefix}ban\` — Bannir\n\`${prefix}clear <n>\` — Supprimer des messages\n\`${prefix}renew\` — Recréer un salon\n\`${prefix}slowmode\` — Mode lent\n\`${prefix}voicemute\` — Mute vocal\n\`${prefix}voiceunmute\` — Unmute vocal\n\`${prefix}unban <id>\` — Débannir\n\`${prefix}unbanall\` — Débannir tout le monde\n\`${prefix}warn\` — Avertir\n\`${prefix}unwarn\` — Retirer un avertissement\n\`${prefix}warnlist\` — Voir les avertissements`,
    },
    logs: {
      title: '📋 Logs du serveur',
      desc: `\`${prefix}presetlogs\` — Créer et configurer tous les salons logs\n\`${prefix}messagelog\` — Logs des messages supprimés/édités\n\`${prefix}modlog\` — Logs des actions de modération\n\`${prefix}ticketlog\` — Logs des tickets\n\`${prefix}giveawaylog\` — Logs des giveaways\n\`${prefix}boostlog\` — Logs des boosts\n\`${prefix}raidlog\` — Logs des actions antiraid`,
    },
    giveaway: {
      title: '🎊 Giveaway',
      desc: `\`${prefix}giveaway\` — Lancer un Giveaway\n\`${prefix}end [ID]\` — Terminer un Giveaway\n\`${prefix}reroll [ID]\` — Reroll un Giveaway`,
    },
    jeux: {
      title: '🎯 Jeux & Fun',
      desc: `\`${prefix}8ball <question>\` — Poser une question\n\`${prefix}ascii <texte>\` — Écrire en ASCII\n\`${prefix}catsay <texte>\` — Un chat qui parle\n\`${prefix}dogsay <texte>\` — Un chien qui parle\n\`${prefix}foxsay <texte>\` — Un renard qui parle\n\`${prefix}click\` — Jeu de rapidité\n\`${prefix}combat\` — Combattre un membre\n\`${prefix}gif\` — Rechercher un GIF\n\`${prefix}gay\` — Combien de % gay\n\`${prefix}hack\` — Faux hack\n\`${prefix}insta\` — Recherche Instagram\n\`${prefix}mot\` — Jeu du pendu\n\`${prefix}gunfight\` — Duel au pistolet\n\`${prefix}puissance4\` — Jeu Puissance 4\n\`${prefix}snake\` — Jeu du serpent\n\`${prefix}fessé\` — Donner une fessée\n\n**Couple & Mariage**\n\`${prefix}marry <user>\` — Demander en mariage\n\`${prefix}divorce\` — Divorcer\n\`${prefix}couple\` — Voir votre statut de couple`,
    },
    activity: {
      title: '🎮 Activity Together',
      desc: `\`${prefix}activity\` — Lancer une activité dans votre salon vocal\n\n**Activités disponibles :**\nYoutube • Poker • Chess • Checkers in the Park\nBetrayal • Fishington • Letter Tile • Words Snack\nDoodle Crew • SpellCast • Awkord • Puttparty\nSketchheads • Ocho`,
    },
    vocal: {
      title: '🔊 Vocal & Temporaire',
      desc: `\`${prefix}tempvoc\` — Menu de gestion vocal temporaire\n\`${prefix}tempvocpanel\` — Panel de configuration vocaux temporaires\n\`${prefix}antijoin on/off\` — Empêcher de rejoindre les vocaux\n\`${prefix}vwl <user>\` — Autoriser un membre (Voice Whitelist)\n\`${prefix}unvwl <user>\` — Retirer la permission vocale\n\`${prefix}blv <user>\` — Bannir des vocaux (Blacklist Voice)\n\`${prefix}unblv <user>\` — Débannir des vocaux`,
    },
    config: {
      title: '⚙️ Configuration & Outils (Admins)',
      desc: `\`${prefix}ticketset\` — Créer un système ticket pré-défini\n\`${prefix}permticket\` — Configurer le rôle ticket\n\`${prefix}setcategorie\` — Catégorie des tickets\n\`${prefix}setsuggest\` — Salon de suggestions\n\`${prefix}setupSuggestMsg\` — Message du module suggestion\n\`${prefix}transcript\` — Récupérer tous les messages d'un salon\n\`${prefix}embed\` — Créer un embed (embed builder)\n\`${prefix}buttonrole <role> <description>\` — Embed bouton pour un rôle\n\`${prefix}prefix\` — Changer le préfixe\n\`${prefix}muterole\` — Mettre en place un rôle muet\n\`${prefix}soutien\` — Choisir un rôle et statut de soutien`,
    },
  };

  const data = categories[category] || categories['home'];
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(data.title)
    .setDescription(data.desc)
    .setFooter({ text: `緑 • Midori 🌿 • Préfixe actuel : ${prefix}` });
}
