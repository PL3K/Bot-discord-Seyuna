const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`\n緑 ─── Midori Bot ───────────────────────────────`);
    console.log(`✅ Connecté en tant que: ${client.user.tag}`);
    console.log(`📊 Serveurs: ${client.guilds.cache.size}`);
    console.log(`🗂️  Commandes: ${client.commands.size}`);
    console.log(`緑 ─────────────────────────────────────────────\n`);

    const activities = [
      { name: 'Seyuna 🌸', type: ActivityType.Watching },
      { name: 'Préfixe: +', type: ActivityType.Playing },
      { name: '+help pour les commandes', type: ActivityType.Listening },
    ];

    let i = 0;
    const set = () => {
      const act = activities[i % activities.length];
      client.user.setPresence({ activities: [act], status: 'dnd' });
      i++;
    };
    set();
    setInterval(set, 15000);

    // Vérifications giveaways actifs
    try {
      const db = require('../systems/database');
      for (const [, guild] of client.guilds.cache) {
        const actives = db.giveaways.getActive.all(guild.id);
        for (const ga of actives) {
          if (!ga.ends_at) continue;
          const remaining = ga.ends_at - Date.now();
          if (remaining <= 0) {
            require('../systems/giveaway').endGiveaway(client, ga);
          } else {
            setTimeout(() => require('../systems/giveaway').endGiveaway(client, ga), remaining);
          }
        }
      }
    } catch (_) {}
  },
};
