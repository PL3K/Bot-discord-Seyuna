require('dotenv').config({ path: require('path').resolve(__dirname, '.env') });
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('./config/config');
const loadCommands = require('./handlers/commandHandler');
const loadEvents = require('./handlers/eventHandler');
const express = require('express');

// ── Express keep-alive ────────────────────────────────────
const app = express();
app.get('/', (_, res) => res.send('Midori Bot 緑 — En ligne'));
app.listen(config.port, () => console.log(`🌐 Keep-alive sur le port ${config.port}`));

// ── Client Discord ────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.GuildScheduledEvents,
    GatewayIntentBits.AutoModerationConfiguration,
    GatewayIntentBits.AutoModerationExecution,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember, Partials.User],
});

client.commands = new Collection();

loadCommands(client);
loadEvents(client);

// ── Gestion erreurs globale ───────────────────────────────
process.on('unhandledRejection', (err) => {
  if (err?.code === 50013 || err?.code === 50001 || err?.code === 50007) return;
  console.error('[Unhandled]', err?.message || err);
});
process.on('uncaughtException', (err) => {
  console.error('[Exception]', err.message);
});

client.login(config.token).catch(err => {
  console.error('❌ Erreur de connexion:', err.message);
  console.error('💡 Vérifiez votre token Discord dans .env');
  if (err.message.includes('disallowed intents')) {
    console.error('\n⚠️  INTENTS REQUIS — Activez dans le Discord Developer Portal:');
    console.error('   https://discord.com/developers/applications/' + config.clientId + '/bot');
    console.error('   → Activer: MESSAGE CONTENT INTENT');
    console.error('   → Activer: SERVER MEMBERS INTENT\n');
  }
  process.exit(1);
});
